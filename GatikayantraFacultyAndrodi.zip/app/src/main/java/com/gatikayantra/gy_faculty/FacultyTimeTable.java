package com.gatikayantra.gy_faculty;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class FacultyTimeTable extends AppCompatActivity {

    Button TimetableView;
    TextView room,section,subject, fac_name;
    Spinner  day, time;

    serverComm mycom;
     String facultyName,IPadd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty_time_table);
        TimetableView=(Button)findViewById(R.id.veiwTimeTable);
        room=(TextView)findViewById(R.id.roomResp);
        section=(TextView)findViewById(R.id.sectionResp);
        subject=(TextView)findViewById(R.id.subjectResp);
        day=(Spinner)findViewById(R.id.DaySpinner);
        time=(Spinner)findViewById(R.id.TimeSpinner);
        fac_name=(TextView)findViewById(R.id.faculty_name_MTT);
        mycom=new serverComm();
        Intent intent=getIntent();
        facultyName=intent.getExtras().getString("FacName");
        IPadd=intent.getExtras().getString("IPAdd");

        init();

        TimetableView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mess=mycom.getText(IPadd,"lect_timetable "+facultyName +" "+String.valueOf(time.getSelectedItemPosition())+" "+String.valueOf(day.getSelectedItem()));
                if(mess.equals("F\n")){
                    Toast.makeText(getApplicationContext(),"Error", Toast.LENGTH_SHORT)
                            .show();
                }

                else if(!mess.equals("")){
                    String[] det=mess.split(" ");
                    room.setText(det[0]);
                    section.setText(det[1]);
                    subject.setText(det[2]);
                }




            }
        });




    }








    void init(){
        mycom.setSpinnerArray(IPadd,this,day,"day");
        mycom.setSpinnerArray(IPadd,this,time,"stl normal");
        fac_name.setText(facultyName);



    }
}
