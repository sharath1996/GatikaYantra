package com.gatikayantra.gy_faculty;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Announcments extends AppCompatActivity {
    TextView faculty_name;
    Button announce;
    EditText message;
    Spinner room;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announcments);
        faculty_name=(TextView)findViewById(R.id.Faulty_name_Ann);
        announce=(Button)findViewById(R.id.AnnounceNow);
        message=(EditText)findViewById(R.id.message);
        room=(Spinner) findViewById(R.id.roomList);
        Intent intent=getIntent();
       final String IPadd=intent.getExtras().getString("IPAdd");
        final serverComm mycomm=new serverComm();
        mycomm.setSpinnerArray(IPadd,this,room,"rml");


        final String lectName=intent.getExtras().getString("FacName");
       faculty_name.setText(lectName);


        announce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mycomm.getResponse(IPadd,"announce:"+String.valueOf(room.getSelectedItem())+":"+String.valueOf(lectName+":"+message.getText().toString()));
                Toast.makeText(getApplicationContext(),"Announced ", Toast.LENGTH_SHORT)
                        .show();

                message.setText("");
            }
        });
    }
}
