try:
    hosts=['192.168.0.105','192.168.0.106']
    rooms=['SES209','SES411']
    i=0
    for host in hosts:
        room=rooms[i]
        print 'connecting to:',room,' ip:',host
        gybasicops.glow_room_led([room,True])
        i+=1
except:
    print 'error reaching server:',room,host       
