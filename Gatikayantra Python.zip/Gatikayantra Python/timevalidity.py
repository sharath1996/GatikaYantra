
def check(x):
    try:
        if x!=[] and x[0]!='' and x[1]!='':
            request=x
            stvalue=request[0]
            etvalue=request[1]
            stvalue1=stvalue.split(":")
            etvalue1=etvalue.split(":")
            etvalue2=""
            stvalue2=""
            len1=len(stvalue1)
            len2=len(etvalue1)
    
            if (len1==3 and len2==3):
                EndHr=(etvalue1[0])
                EndMin=(etvalue1[1])
                EndSec=(etvalue1[2])
                StHr=(stvalue1[0])
                StMin=(stvalue1[1])
                StSec=(stvalue1[2])

            for z1 in etvalue1:
                etvalue2=etvalue2+z1
            for z1 in stvalue1:
                stvalue2=stvalue2+z1

            if ((stvalue.count(":",0,len(stvalue))!=2) or (etvalue.count(":",0,len(etvalue))!=2)):
                return False 
                #print "Tf"

            elif((etvalue2.isdigit()!=True)or(stvalue2.isdigit()!=True)):  
                return False
                #print r2,q2
    
            else:
                if ((len1!=3) or (len2!=3)):
                    return False

        
                elif (EndHr=="" or EndMin=='' or EndSec=='' or StHr=='' or StMin=='' or StSec==''):
                    return False

                elif(int(EndHr)>24 or int(EndMin)>60 or int(EndSec)>60 or int(StHr)>24 or int(StMin)>60 or int(StSec)>60):
                    return False

                else:
                    return True
        else:
            return False
    except:
        return 0

def switching_time(tym):
    try:
        fo=open('switch_status.txt','w+')
        if tym>'07:00:00' and tym<'19:00:00':
                fo.write('turnoff')
                val=True
        else:
                fo.write('turnon')
                val=False
        fo.close()
        return val
    except:
        fo.close()
        return 0

def get_time(typ):
    import time
    try:
        if (typ=='time'):
            t1=time.strftime("%H:%M:%S",time.localtime())
            return t1
        elif (typ=='date'):
            date=time.strftime("%d/%m/%Y",time.localtime())
            return date
        elif (typ=='day'):
            day=time.strftime("%A",time.localtime())
            return day
        else:
            return 0
    except:
        return 0

