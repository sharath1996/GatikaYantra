package com.gatikayantra.gy_faculty;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.audiofx.BassBoost;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class LoginActivity extends AppCompatActivity {

    EditText password;
    Spinner facultyList;
    Button Login,passwordchange;
    serverComm comm;
    EditText IPADD;
    String fileName = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        password=(EditText)findViewById(R.id.PasswordEntry);
        facultyList=(Spinner)findViewById(R.id.FacultyList);
        Login=(Button)findViewById(R.id.loginButton);
        passwordchange=(Button)findViewById(R.id.SettingsButton);

        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        final String ipadd=settings.getString("server_ip","");
        comm=new serverComm();
        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        comm.setSpinnerArray(ipadd,this,facultyList,"lectName");



        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                String resp=password.getText().toString();

                String j=comm.getText(ipadd,"aut "+String.valueOf(facultyList.getSelectedItemPosition())+" "+resp);
                if(!j.equals("F\n")){
                    String[] Resp=j.split("-");

                    fileName=ipadd;

                    String reply=Resp[3].replace('#','\n');

                    alertDialogBuilder.setMessage("You have class at\nRoom: "+Resp[0]+"\n" + "Section: "+Resp[1]+"\n"+"Subject: "+Resp[2]+"\n"+"message :"+reply);
                    alertDialogBuilder.setPositiveButton("OK GOT IT", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface arg0, int arg1) {

                                    Intent intent1= new Intent(v.getContext(), HomeScreen.class);
                                    intent1.putExtra("Fname",String.valueOf(facultyList.getSelectedItem()));
                                    intent1.putExtra("IPAddress1",fileName);
                                    intent1.putExtra("FullName",String.valueOf(facultyList.getSelectedItemPosition()));
                                    startActivity(intent1);

                                    finish();
                                }
                            }
                    );

                    alertDialogBuilder.create();
                    alertDialogBuilder.show();


                }
                else if (j.equals("F\n"))
                    Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_SHORT)
                            .show();
            }
        });


        passwordchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1= new Intent(v.getContext(),SettingsActivity.class);
                startActivity(intent1);



            }
        });
    }


}
