package com.gatikayantra.gy_controlpanel;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CalenderActivity extends AppCompatActivity {
    Button viewMode,setMode,calenderLauncehr;
    Spinner modeList;
    TextView modeText;
    Calendar calendar;
    int year, month, day;
    String date,formattedDate,ipAdressClient="",ipaddServer="";
    serverComm myserver=new serverComm();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calender);

        viewMode=(Button)findViewById(R.id.viewMode);
        setMode=(Button)findViewById(R.id.setMode);
        calenderLauncehr=(Button)findViewById(R.id.calenderLauncher);


        modeList=(Spinner)findViewById(R.id.modeDetails);
        modeText=(TextView)findViewById(R.id.modeTextView);

        calendar = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        formattedDate = df.format(calendar.getTime());
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        final Intent intent=getIntent();
        ipAdressClient=intent.getExtras().getString("bellIP");
        ipaddServer=intent.getExtras().getString("mainServerIP");
        init();

       calenderLauncehr.setOnClickListener(new View.OnClickListener() {
            @Override
            @SuppressWarnings("deprecation")
            public void onClick(View v) {

                showDialog(999);

            }
        });

    }


    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this, myDateListener, year, month, day);
        }
        return null;
    }
    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {

            try {
                showDate(arg1, arg2+1, arg3);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    };


    private void showDate(int year, int month, int day) throws ParseException {
        String dateNow=(new StringBuilder().append(day).append("/").append(month).append("/").append(year)).toString();

        Toast.makeText(getApplicationContext(), dateNow, Toast.LENGTH_SHORT)
                .show();
        date = dateNow;



    }
    public void setModeFunction(View view) {


        myserver.getResponse(ipaddServer,"setCal "+String.valueOf(modeList.getSelectedItem())+" "+date);
        init();
    }

    public void viewModeFunction(View view) {
        myserver.setTextView(ipaddServer,modeText, "cal "+date);


    }
    void init(){
        myserver.setSpinnerArray(ipaddServer,this,modeList,"mod");
        myserver.setTextView(ipaddServer,modeText, "cal "+formattedDate);

    }
}
