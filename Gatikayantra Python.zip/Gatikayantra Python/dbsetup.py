import sqlite3

def erase_db():
    try:
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        tables=['login','subjects','normaltime','internalstime','examtime','A','B','C','D','staffs','specialdates','sections','rooms']
        db.execute('select * from sections')
        secs=db.fetchall()
        db.execute('select * from rooms')
        rooms=db.fetchall()
        db.execute('select name from staffs')
        staffs=db.fetchall()
        
        for a in tables:
            db.executescript('drop table if exists '+a)
            
        for a in secs:
            a=''.join(a)#tuple to string
            db.executescript('drop table if exists _'+a)
            db.executescript('drop table if exists _'+a+'sdb')
            
        for a in rooms:
            a=''.join(a)#tuple to string
            db.executescript('drop table if exists '+a)
        
        for a in staffs:
            a=''.join(a)#tuple to string
            db.executescript('drop table if exists _'+a)
        dbase.commit()
        db.close()
        return 1
    
    except:
        db.rollback()
        db.close()
        print 'exception in erase_db'
        return 0
    

def create_db():
    try:
        erase_db()
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        
        db.execute('''create table login
        (id int primary key,username text,password text);''')
        db.execute('insert into login values(?,?,?)',(1,'admin','admin'))

        db.execute('''create table specialdates
        (date text,mode text);''')

        db.execute('''create table rooms (room text);''')

        db.execute('''create table sections
        (sec text);''')

        db.execute('''create table normaltime
        (id integer primary key,starttime text,endtime text);''')

        db.execute('''create table internalstime
        (id integer primary key,starttime text,endtime text);''')

        db.execute('''create table examtime
        (id integer primary key,starttime text,endtime text);''')

        db.execute('''create table staffs
        (id integer primary key,name text,password text);''')

        dbase.commit()
        db.close()
        return True
    except:
        db.close()
        print 'exception in dbsetup.create_db'




        
