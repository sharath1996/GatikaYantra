
import RPi.GPIO as GPIO
import dbsetup
import time
import readDbase
import studentDB
import staffsDB
#import pygame.mixer
#import pyttsx

def delete_db(channel):
    try:
        print 'detected - reset_pin: ',channel
        GPIO.output(reply_led,GPIO.HIGH)
        resp=dbsetup.erase_db()
        GPIO.output(reply_led,GPIO.LOW)
        GPIO.output(reply_ard, GPIO.LOW)
        time.sleep(0.3)
        GPIO.output(reply_ard, GPIO.HIGH)
        
        
        if resp:
            print 'erased sucessfully'
            blink_led(1)
        else:
            print 'not erased'
            ring_buz(2)
    except:
        print 'error in gybasicops.deletedb'
        return 0
    
def primary_update(channel):
    try:
        print 'detected - update_primary_pin: ',channel
        GPIO.output(reply_led,GPIO.HIGH)
        resp=readDbase.read_ipaddrs()
        GPIO.output(reply_led,GPIO.LOW)
        GPIO.output(reply_ard, GPIO.LOW)
        time.sleep(0.3)
        GPIO.output(reply_ard, GPIO.HIGH)
        
        if resp:
            blink_led(1)
        else:
            ring_buz(2)
    except:
        print 'error in gybasicops.primary_update'

def complete_update(channel):
    try:
        print 'detected - update_full_pin: ',channel
        path='/media/pi/GYANTRA/gatikayantra.xls'
        path1='/media/pi/GYANTRA/gatikayantra_deviceip.xls'
        fo=open(path,'r+')
        fo.close()
        fo=open(path1,'r+')
        fo.close()
        progress=progress_status('True')
        #print 'progress: ',progress
        GPIO.output(reply_led,GPIO.HIGH)
        flag1=readDbase.prepare_timelist(path)
        flag2=readDbase.read_sec_list(path)
        flag3=readDbase.read_room_list(path)
        flag4=readDbase.prepare_timetable(path)
        flag7=staffsDB.prepare_staffs_timetable(path)
        flag8=readDbase.read_ipaddrs(path1)
        flag5=studentDB.subject_db(path)
        flag6=studentDB.read_sdb(path)
        GPIO.output(reply_led,GPIO.LOW)
        '''GPIO.output(reply_ard, GPIO.LOW)
        time.sleep(0.3)
        GPIO.output(reply_ard, GPIO.HIGH)'''
        progress=progress_status('False')
        print 'progress: ',progress
        print 'timelist: ',flag1
        print 'section list: ', flag2
        print 'timetable: ',flag4
        print 'subject database: ',flag5
        print 'student database: ',flag6
        print'staffs timetable: ',flag7
        print 'ip adress: ',flag8

        if flag1 and flag2 and flag3 and flag4  and flag5 and flag6 and flag7 and flag8:
            resp=True
            print 'sucessfull'
        else:
            print 'failed'
            resp=False
        
        if resp:
            blink_led(1)
        else:
            ring_buz(2)
        return None
    except IOError as e:#to avoid erase of dtabase when pendrive is not inserted
        print "file not found!!!.Please insert pendrive"
        ring_buz(2)
        progress=progress_status('False')
        blink_led(5)
        #print 'progress :',progress
    except:
        print "something went wrong in: gybasicops.complete_update(channel)"
        ring_buz(2)
        progress=progress_status('False')
        blink_led(5)
        #print 'progress :',progress
    
def diagnostics(channel):
    try:
        print 'detected - self_diagnostics_pin: ',channel
        GPIO.output(reply_led,GPIO.HIGH)   
        GPIO.output(reply_led,GPIO.LOW)
        GPIO.output(reply_ard, GPIO.LOW)
        time.sleep(0.3)
        GPIO.output(reply_ard, GPIO.HIGH)
    except:
        print 'exception in gybasicops.diagnostics'


def setup_hardware():
    try:
        global reply_led,reply_buz,switch_pin,reply_ard
        GPIO.setmode(GPIO.BCM)
        '''reset_pin=17
        update_primary_pin=27
        self_diagnostics_pin=10'''
        update_full_pin=22
        reply_led=9
        reply_buz=11
        interrupt_type=GPIO.RISING
        switch_pin=24
        #reply_ard=8
        
        '''GPIO.setup(reset_pin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
        GPIO.setup(update_primary_pin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
        GPIO.setup(self_diagnostics_pin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)'''
        GPIO.setup(update_full_pin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
        GPIO.setup(reply_led, GPIO.OUT)
        GPIO.output(reply_led, GPIO.LOW)
        GPIO.setup(reply_buz, GPIO.OUT)
        GPIO.output(reply_buz, GPIO.LOW)
        GPIO.setup(switch_pin, GPIO.OUT)
        #GPIO.output(switch_pin, GPIO.LOW)    
        '''GPIO.setup(reply_ard,GPIO.OUT)
        GPIO.output(reply_ard, GPIO.HIGH)'''

        room_led_pin=[26,19,13,6]
        for pin in room_led_pin:
            GPIO.setup(pin, GPIO.OUT)
            GPIO.output(pin, GPIO.LOW)
        
        #GPIO.add_event_detect(reset_pin,interrupt_type, callback=delete_db, bouncetime=20) 
        #GPIO.add_event_detect(update_primary_pin, interrupt_type , callback=primary_update, bouncetime=20)
        #GPIO.add_event_detect(self_diagnostics_pin, interrupt_type , callback=diagnostics, bouncetime=20)
        GPIO.add_event_detect(update_full_pin, interrupt_type , callback=complete_update, bouncetime=500) 
        print 'done setting up hardware'
        return 1
    except:
        print'failed to setup hardware'
        return 0

def glow_room_led(params):
    try: 
        room=params[0]
        flag=params[1]
        room_led_pin={'SES209':26,'SES303':19,'SES405':13,'SES411':6}
        if flag:
            GPIO.output(room_led_pin[room], GPIO.LOW)
            time.sleep(0.1)
            GPIO.output(room_led_pin[room], GPIO.HIGH)
        else:
            GPIO.output(room_led_pin[room], GPIO.LOW)
        return None
    except:
        return None

def room_led_off():
    room_led_pins=[26,19,13,6]
    for room in room_led_pins:
        GPIO.output(room, GPIO.LOW)

def blink_led(val):
    while val>0:
        GPIO.output(reply_led,GPIO.HIGH)
        time.sleep(0.3)
        GPIO.output(reply_led,GPIO.LOW)
        val-=1

def ring_buz(val):
    while val>0:
        GPIO.output(reply_buz,GPIO.HIGH)
        time.sleep(2)
        GPIO.output(reply_buz,GPIO.LOW)
        val-=1
       

def progress_status(val):
    val2=val
    #print "progress val=",val
    if val2.lower()=='check':
        fo=open('progress.txt','r+')
        resp=fo.read()
        fo.close()
    else:
        fo=open('progress.txt','w+')
        fo.write(val)
        fo.close()
        resp='changed'
    return resp

def ring_bell(status):#tested ok
    try:
        '''pygame.mixer.init()
        pygame.mixer.music.load('/home/pi/NIEproject/nov6/sounds/bell-ringing-03.mp3')
        pygame.mixer.music.play()
        fo=open('timetrack.txt','r+')
        ses_num=fo.read()
        fo.close()
        print 'session number : ',ses_num
        engine=pyttsx.init()
        engine.setProperty('rate',150)
        statement='session '+ses_num+' '+status+' now'
        print statement
        engine.say(statement)
        engine.runAndWait() '''
        pass
    except: 
        return None

def clear_gpio():
    GPIO.cleanup()
    return None

def switching_pin_status():
    try:
        fo=open('switch_status.txt','r+')
        status=fo.read()
        fo.close()
        if status=='turnoff':
            GPIO.output(switch_pin,GPIO.LOW)
        else :
            GPIO.output(switch_pin,GPIO.HIGH)
    
        return 1
    except:
        return 0
    
