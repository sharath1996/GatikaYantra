package com.gatikayantra.gy_faculty;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class HomeScreen extends AppCompatActivity {
    TextView fac_name;
    Button mytimetable, search, announcement,changePassword,studentDatabase,messenger;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        fac_name=(TextView)findViewById(R.id.Faculty_name_HS);
        mytimetable=(Button)findViewById(R.id.MTT);
        search=(Button)findViewById(R.id.searchB);
        announcement=(Button)findViewById(R.id.Announ);
        changePassword=(Button)findViewById(R.id.changePasswordButton);
        messenger=(Button)findViewById(R.id.messenger);
        studentDatabase=(Button)findViewById(R.id.student_db);
        final Intent intent=getIntent();
        final String lectName=intent.getExtras().getString("Fname");
        final String lectcode=intent.getExtras().getString("FullName");
        final String ipAdd=intent.getExtras().getString("IPAddress1");

        fac_name.setText(lectName);



        mytimetable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent1= new Intent(v.getContext(), FacultyTimeTable.class);
                intent1.putExtra("FacName",lectName);
                intent1.putExtra("IPAdd",ipAdd);
                startActivity(intent1);



            }

        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent1= new Intent(v.getContext(), SearchActivity.class);
                intent1.putExtra("FacName",lectName);
                intent1.putExtra("IPAdd",ipAdd);
                startActivity(intent1);



            }

        });
        announcement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent1= new Intent(v.getContext(), Announcments.class);
                intent1.putExtra("FacName",lectName);
                intent1.putExtra("IPAdd",ipAdd);
                startActivity(intent1);



            }

        });
        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


               Intent intent1= new Intent(v.getContext(), PasswordActivity.class);
                    intent1.putExtra("Fname",lectcode);
                    intent1.putExtra("IPAddress1",ipAdd);
                    intent1.putExtra("FullName",lectName);
                    startActivity(intent1);



            }

        });

        studentDatabase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent1= new Intent(v.getContext(), StudentDatabase.class);
                intent1.putExtra("Fname",lectcode);
                intent1.putExtra("IPAdd",ipAdd);
                intent1.putExtra("FullName",lectName);
                startActivity(intent1);



            }

        });
        messenger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent1= new Intent(v.getContext(), messagingActivity.class);
                intent1.putExtra("FacName",lectName);
                intent1.putExtra("IPAdd",ipAdd);
                startActivity(intent1);



            }

        });


    }


}
