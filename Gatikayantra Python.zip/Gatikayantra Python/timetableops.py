import gydb
from bellops import get_session_num

def tostring(lst,typ):
    try:
        data=''
        for a in lst:
            data=data+''.join(a)+typ
        return data[0:len(data)-1]
    except:
        print 'exception in timetableops'
        return 0

def get_room_period(x):
    try:
        query=x.split()
        day=query[1].lower()
        time=int(query[2])+1
        room=query[3].upper()
        statement='select '+day+' from '+room+' where id=?'
        #print statement,query
        period=gydb.opentimetable(statement,time)
        if period==None:
            return False
        else:
            return period

    except:
        return 'F'

def get_sec_period(x):
    try:
        query=x.split()
        day=query[3].lower()#DAY
        timeindex=int(query[2])+1#timeindex
        sec=query[1].upper()#room
        statement='select '+day+' from _'+sec+' where id=?'
        period=gydb.opentimetable(statement,timeindex)
        if period==None:
            return False

        else:
            return period
    except:
        return False


def edit_room_timetable(x):
    try:
        query=x.split()
        day=query[1].lower()
        timeindex=int(query[2])
        room=query[3].upper()
        section=query[4]
        if len(query)>5:
            lname=query[5]
            sname=query[6]
    
            typ=1        
            statement='update '+room+' set '+day+'=? where id=? and typ=?'
            data=[section,timeindex,typ]
            if gydb.updatedb(statement,data):
                typ=2
                data=[sname,timeindex,typ]
                gydb.updatedb(statement,data)
                typ=3
                data=[lname,timeindex,typ]
                gydb.updatedb(statement,data)
                return True
            
            else:
                return False
        else:
            return False
    except:
        return False


def edit_sec_timetable(x):
    try:
        query=x.split()
        day=query[1].lower()
        timeindex=int(query[2])
        room=query[3].upper()
        section=query[4]
        if len(query)>5:
            lname=query[5]
            sname=query[6]
    
            typ=1        
            statement='update _'+section+' set '+day+'=? where id=? and typ=?'
            data=[room,timeindex,typ]
            if gydb.updatedb(statement,data):
                typ=2
                data=[sname,timeindex,typ]
                gydb.updatedb(statement,data)
                typ=3
                data=[lname,timeindex,typ]
                gydb.updatedb(statement,data)
                return True
            
            else:
                return False
        else:
            return False
    except:
        return False


def server_config_tt(room,day):
    try:
        session=get_session_num()
        if session>0:
            idnum=str(session-1)
            data='blank '+day+' '+idnum+' '+room
            period=get_room_period(data)
            if period==None or period==0:
                period1="free-free-free-free"        
            else:
                period=tostring(period,'-')
                period1=room+'-'+period
            return period1
        else:
            return 'F-F-F-F'
    except:
        print 'excption in timetableops.server_config_tt'
        return 'F-F-F-F'
    
def rm_frm_ip(address):
    try:
        statement='select device from device_ips where ipaddrs=?'
        room=''.join(gydb.opendbone(statement,address))
        if room==None:
            room=0
        return room
    except:
        print 'exception in timetableops.rm_frm_ip'
        return 0
