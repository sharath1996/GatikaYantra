package com.gatikayantra.gatikayantraviewer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.BatteryManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static com.gatikayantra.gatikayantraviewer.R.layout.activity_login;

public class LoginActivity extends AppCompatActivity {
    TextView room,subject,faculty,section,Announcment;
    private BroadcastReceiver mReceiver;
    String finalMessage;
    RelativeLayout lLayout;
    ServerComm mycom=new ServerComm();




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(activity_login);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);


        lLayout = (RelativeLayout) findViewById(R.id.activity_login);
        room = (TextView)findViewById(R.id.room);
        subject=(TextView)findViewById(R.id.subject);
        faculty=(TextView)findViewById(R.id.faculty);
        section=(TextView)findViewById(R.id.section);
        Announcment=(TextView)findViewById(R.id.information) ;
        Announcment.setVisibility(View.GONE);
        lLayout.setBackgroundColor(Color.parseColor("#FFFFFFFF"));

        mReceiver = new BatteryBroadcastReceiver();


        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    //Create a server socket object and bind it to a port
                    ServerSocket socServer = new ServerSocket(6000);
                    //Create server side client socket reference
                    Socket socClient = null;
                    //Infinite loop will listen for client requests to connect
                    while (true) {
                        //Accept the client connection and hand over communication to server side client socket
                        socClient = socServer.accept();
                        //For each client new instance of AsyncTask will be created
                        ServerAsyncTask serverAsyncTask = new ServerAsyncTask();
                        //Start the AsyncTask execution
                        //Accepted client socket object will pass as the parameter
                        serverAsyncTask.execute(new Socket[] {socClient});
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();





    }
    @Override
    protected void onStart() {
        registerReceiver(mReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        super.onStart();
    }



    @Override
    protected void onStop() {
        unregisterReceiver(mReceiver);
        super.onStop();
    }



    private class BatteryBroadcastReceiver extends BroadcastReceiver {


        @Override
        public void onReceive(Context context, Intent intent) {

            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);

            if(level<20){
                mycom.getResponse("BL");

            }
           else if(level>95){
                mycom.getResponse("BF");

            }

        }
    }




    class ServerAsyncTask extends AsyncTask<Socket, Void, String> {
        //Background task which serve for the client
        @Override
        protected String doInBackground(Socket... params) {
            String result = null;
            //Get the accepted socket object
            Socket mySocket = params[0];
            try {

                BufferedReader in = new BufferedReader(new InputStreamReader(mySocket.getInputStream()));//Get the data input stream comming from the client

                finalMessage =in.readLine()+System.getProperty("line.separator");//Get the output stream to the client
                String response = finalMessage;
                String rep="T\n",rep2="T\n";


                    PrintWriter out = new PrintWriter(mySocket.getOutputStream(), true);
                if(response.equals("getTime\n")) {
                    Calendar c = Calendar.getInstance();
                   SimpleDateFormat df = new SimpleDateFormat("EEE MMM dd HH:mm:ss yyyy");
                  //  SimpleDateFormat sdf = new SimpleDateFormat("EEE");
             //       Date d = new Date();
                    String dayOfTheWeek = df.format(c.getTime());//" "+sdf.format(d);
                   rep=dayOfTheWeek;


                }


                out.println(rep);
                result = finalMessage;
                //Close the client connection
                Log.w("server","SEDDD");
                mySocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            Log.w("server","PostExecte");
            if(!s.equals("getTime\n")){
            String[] res=s.split("-"); //After finishing the execution of background task data will be write the text view
            if(res[0].equals("message")){
                Toast.makeText(getApplicationContext(),res[1], Toast.LENGTH_SHORT)
                        .show();
                Announcment.setVisibility(View.VISIBLE);
                lLayout.setBackgroundColor(Color.parseColor("#FFFB7743"));
               Announcment.setText(res[1]);
            }

            else {
                lLayout.setBackgroundColor(Color.parseColor("#FFFFFFFF"));

                room.setText(res[0]);
                section.setText(res[1]);
                faculty.setText(res[3]);
                subject.setText(res[2]);}


        }

        }
    }


}




