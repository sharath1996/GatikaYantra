import sqlite3


def opendbone(statement,key):
    dbase=sqlite3.connect('gatikayantra.db')
    db=dbase.cursor()
    #key1=tuple(key)
    db.execute(statement,(key,))
    usrpsw=db.fetchone()
    #print usrpsw
    db.close()
    return usrpsw


def updatedb(statement,key):
    try:
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        key=tuple(key)
        if db.execute(statement,key):
            dbase.commit()
            db.close()
            return True
        else:
            db.close()
            return False
    except:
        return False

def opendball(statement):
    dbase=sqlite3.connect('gatikayantra.db')
    db=dbase.cursor()
    db.execute(statement)
    data=db.fetchall()
    #print data
    db.close()
    return data

def addtodb(statement,data):
    dbase=sqlite3.connect('gatikayantra.db')
    db=dbase.cursor()
    data1=[None]+data
    data1=tuple(data1)
    #print data1
    #print statement
    resp=db.execute(statement,data1)
    dbase.commit()
    db.close()
    return resp

def opentimetable(statement,idnum):
    dbase=sqlite3.connect('gatikayantra.db')
    db=dbase.cursor()
    db.execute(statement,(idnum,))
    data=db.fetchall()
    #print data
    db.close()
    return data

def deletedb(statement,data):
    dbase=sqlite3.connect('gatikayantra.db')
    db=dbase.cursor()
    if db.execute(statement,data)!=None:
        dbase.commit()
        db.close()
        return True
    else:
        db.close()
        return False


def appendtodb(statement,data):
    dbase=sqlite3.connect('gatikayantra.db')
    db=dbase.cursor()
    print statement,data
    resp=db.execute(statement,data)
    print resp
    if resp!=None:
         dbase.commit()
         db.close()
         return True
    else:
        db.close()
        return False    
def change_table_name(old_name,new_name):
    dbase=sqlite3.connect('gatikayantra.db')
    db=dbase.cursor()
    statement="alter table "+old_name+" rename to "+new_name
    db.execute(statement)
    dbase.commit()
    db.close()
    
