package com.gatikayantra.gy_faculty;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class StudentDatabase extends AppCompatActivity {
    Button databaseSelector;
    EditText Usn;
    Spinner sectionList;
    String IPadd="";
    serverComm myserver=new serverComm();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_database);
        Usn=(EditText)findViewById(R.id.USNselector);
        sectionList=(Spinner)findViewById(R.id.sectionSelector);
        Intent intent=getIntent();
        IPadd=intent.getExtras().getString("IPAdd");

        init();
    }

    public void databaseAccess(View view) {
        String usn=Usn.getText().toString();
        String sec=String.valueOf(sectionList.getSelectedItem());
        String status = myserver.getText(IPadd,"search_student "+Usn.getText().toString().toUpperCase()+" "+sec);

        if (!status.equals("F\n")){
// activate the window
            Intent intent1= new Intent(view.getContext(), studentDetails.class);
            intent1.putExtra("StudentName",status);
            intent1.putExtra("IPAdd",IPadd);
            intent1.putExtra("SectionName",String.valueOf(sectionList.getSelectedItem()));
            intent1.putExtra("USN",Usn.getText().toString().toUpperCase());
            startActivity(intent1);
        }
        else Toast.makeText(getApplicationContext(), "USN not found...\n Please verify and enter again", Toast.LENGTH_SHORT)
                .show();




    }
    void init(){
        myserver.setSpinnerArray(IPadd,this,sectionList,"sec");
    }
}
