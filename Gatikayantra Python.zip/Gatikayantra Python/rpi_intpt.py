import RPi.GPIO as GPIO
import time
import dbsetup
def my_callback(channel):
    print 'falling edge detected on 17'
    resp=dbsetup.erase_db()
    if resp:
        print 'earased sucessfully'
    else:
        print 'not erased'

def my_callback2(channel):
    print 'falling edge detected on 23'
    resp=dbsetup.create_db()


def my_callback3(channel):
    print 'rising edge detected on 24'

print 'jhscbHSBJBHJ'


def interrupt():
    GPIO.setmode(GPIO.BCM)
    global replay_pin
    replay_pin=9
    GPIO.setup(23, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(17, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

    GPIO.setup(24, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(replay_pin, GPIO.OUT)
    GPIO.output(replay_pin, GPIO.LOW)
    pin=17
    interrupt_type=GPIO.RISING
    
    GPIO.add_event_detect(pin, interrupt_type, callback=my_callback, bouncetime=30) 

    GPIO.add_event_detect(23, GPIO.RISING, callback=my_callback2, bouncetime=300)

    GPIO.add_event_detect(24, GPIO.RISING, callback=my_callback3, bouncetime=300) 

interrupt()
while 1:
    print 'im waiting'
    time.sleep(3)


GPIO.cleanup()
