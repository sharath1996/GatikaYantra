package com.gatikayantra.gy_controlpanel;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PasswordChangeActivity extends AppCompatActivity {
    EditText nusername,cusername,npassword,cpassword;
    Button UpdateDB;
    String ipaddServer="",ipaddBell="";
    serverComm myserver=new serverComm();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_change);
        nusername=(EditText)findViewById(R.id.nUserName);
        cusername=(EditText)findViewById(R.id.cUserName);
        npassword=(EditText)findViewById(R.id.nPassword);
        cpassword=(EditText)findViewById(R.id.cPassword);
        final Intent intent=getIntent();
        ipaddServer=intent.getExtras().getString("mainServerIP");
        ipaddBell=intent.getExtras().getString("bellIP");
    }

    public void updateChanges(View view) {
        String usern=nusername.getText().toString();
        String usern2=cusername.getText().toString();
        String pass1=npassword.getText().toString();
        String pass2=cpassword.getText().toString();
        if((usern.equals(usern2))&&(pass1.equals(pass2))){
            int j=myserver.getResponse(ipaddServer,"change "+usern+" "+pass1);

            if (j==1){
                Toast.makeText(getApplicationContext(),"username and password updated", Toast.LENGTH_SHORT)
                        .show();}
            else {
                Toast.makeText(getApplicationContext(),"Error Occured", Toast.LENGTH_SHORT)
                        .show();
            }

        }
        else{
            Toast.makeText(getApplicationContext(),"username and password doesnot match", Toast.LENGTH_SHORT)
                    .show();}

    }


    }

