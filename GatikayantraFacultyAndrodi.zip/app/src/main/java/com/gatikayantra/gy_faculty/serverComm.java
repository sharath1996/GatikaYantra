package com.gatikayantra.gy_faculty;

/**
 * Created by sharath on 19/1/17.
 */
import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * Created by Sharath on 22-09-2016.
 */
public class serverComm {

    public void serverComm() {


    }

    Context context;

    public String setSpinnerArray(String IPAdress,Context myContext, Spinner mySpinner, String message) {
        String response = "", list = "", ipadd="";
        this.context = myContext;
        ipadd=IPAdress;
        TCPClient TimeTable = new TCPClient(ipadd, 5000, message);
        TimeTable.execute();
        try {
            list = TimeTable.get().toString();
        } catch (InterruptedException e) {

            e.printStackTrace();
            Toast.makeText(myContext,"Cannot connect to Server....\n Make sure that server is online and try again...", Toast.LENGTH_SHORT)
                    .show();

            return "Error";
        } catch (ExecutionException e) {
            e.printStackTrace();
            Toast.makeText(myContext,"Cannot connect to Server....\n Make sure that server is online and try again...", Toast.LENGTH_SHORT)
                    .show();  list="Error";
            return "Error";

        }
        if(list.equals("Error"))  {
            Toast.makeText(myContext,"Cannot connect to Server....\n Make sure that server is online and try again...", Toast.LENGTH_LONG)
                    .show();

        }
        String[] optionsSelected = list.split(" ");
        int j = optionsSelected.length;

        List<String> section = new ArrayList<String>();

        for (int i = 0; i < j; i++) {
            String Jam=optionsSelected[i].replace("\n","");

            section.add(Jam);

        }

        ArrayAdapter<String> sectnAdapter = new ArrayAdapter<String>(this.context, android.R.layout.simple_spinner_item, section);
        sectnAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(sectnAdapter);

        return "T\n";


    }

    public String setTextView(String IPAdress,TextView myText, String message) {
        String response = "", list = "",ipadd="";
        ipadd=IPAdress;
        TCPClient TimeTable = new TCPClient(ipadd, 5000, message);
        TimeTable.execute();
        try {
            list = TimeTable.get().toString();
        } catch (InterruptedException e) {

            e.printStackTrace();
            return "H";
        } catch (ExecutionException e) {
            e.printStackTrace();
            return "H";
        }

        myText.setText(list);

        return "T\n";



    }

    public int getResponse(String IPAdress,String mesg){

        String response = "", list = "",ipadd="";
        ipadd=IPAdress;
        TCPClient TimeTable = new TCPClient(ipadd, 5000, mesg);
        TimeTable.execute();
        try {
            list = TimeTable.get().toString();
        } catch (InterruptedException e) {

            e.printStackTrace();
            return 0;
        } catch (ExecutionException e) {
            e.printStackTrace();
            return 0;
        }

        if (list.equals("T\n"))
        {

            return 1;
        }

        return 0;
    }
    public String getText(String IPAdress,String mesg){

        String response = "", list = "",ipadd="";
        ipadd=IPAdress;
        TCPClient TimeTable = new TCPClient(ipadd, 5000, mesg);
        TimeTable.execute();
        try {
            list = TimeTable.get().toString();
        } catch (InterruptedException e) {

            e.printStackTrace();
            return "F\n";
        } catch (ExecutionException e) {
            e.printStackTrace();
            return "F\n";
        }



        return list;
    }

}
