package com.gatikayantra.gy_faculty;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class messagingActivity extends AppCompatActivity {
    EditText message;
    Spinner toFaculty;
    TextView fromFaculty;
    serverComm myserver=new serverComm();
    String facultyName="",IPadd="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messaging);
        message=(EditText)findViewById(R.id.smessage);
        toFaculty=(Spinner)findViewById(R.id.facultyList);
        fromFaculty=(TextView)findViewById(R.id.facultyName);
        Intent intent=getIntent();
        facultyName=intent.getExtras().getString("FacName");
        IPadd=intent.getExtras().getString("IPAdd");
        myserver.setSpinnerArray(IPadd,this,toFaculty,"lectName");
        fromFaculty.setText(facultyName);


    }

    public void sendMessage(View view) {
        int resp=myserver.getResponse(IPadd,"messageFrom:"+facultyName+":"+String.valueOf(toFaculty.getSelectedItem())+":"+message.getText().toString());
        if (resp==1){

            Toast.makeText(getApplicationContext(), "Message sent\n Please wait until they reply", Toast.LENGTH_SHORT)
                    .show();
        }
        else Toast.makeText(getApplicationContext(), "Message Sending Failed", Toast.LENGTH_SHORT)
                .show();



    }
}
