package com.gatikayantra.gy_faculty;

import android.content.Intent;
import android.net.IpPrefix;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class studentDetails extends AppCompatActivity {
    TextView studentName,USNnumber,sectionName;
    EditText ia1text,ia2text,ia3text,attendenceEtext;
    String IPadd,studentNameString,sectionString,usnString;
    Spinner sectionSelector;
    Button viewDatabase;


    serverComm myserver=new serverComm();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_details);
        studentName=(TextView)findViewById(R.id.studentNameText);
        USNnumber=(TextView)findViewById(R.id.USNtext);
        sectionName=(TextView)findViewById(R.id.sectionText);
        sectionSelector=(Spinner)findViewById(R.id.SectionSelectorSpinner);
        ia1text=(EditText)findViewById(R.id.IA1EditText);
        ia2text=(EditText)findViewById(R.id.IA2EditText);
        ia3text=(EditText)findViewById(R.id.IA3EditText);
        attendenceEtext=(EditText)findViewById(R.id.attendenceEditText);
        viewDatabase=(Button)findViewById(R.id.viewDB) ;
        Intent intent=getIntent();
        IPadd=intent.getExtras().getString("IPAdd");
        studentNameString=intent.getExtras().getString("StudentName");
        sectionString=intent.getExtras().getString("SectionName");
        usnString=intent.getExtras().getString("USN");

        Toast.makeText(getApplicationContext(),IPadd, Toast.LENGTH_SHORT).show();
        init();


    viewDatabase.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            {
                String resuts=myserver.getText(IPadd,"get_marks "+usnString+" "+sectionString+" "+String.valueOf(sectionSelector.getSelectedItemPosition()));
                String[] resArray=resuts.split("-");
                ia1text.setText(resArray[0]);
                ia2text.setText(resArray[1]);
                ia3text.setText(resArray[2]);
                attendenceEtext.setText(resArray[3]);



            }

        }

    });}





    void init(){
        studentName.setText(studentNameString);
        USNnumber.setText(usnString);
        sectionName.setText(sectionString);
        myserver.setSpinnerArray(IPadd,this,sectionSelector,"get_subjects "+sectionString);


    }
}
