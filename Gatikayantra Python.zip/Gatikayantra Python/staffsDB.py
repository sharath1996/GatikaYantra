import sqlite3
import pyexcel

def prepare_staffs_timetable(path):
    try:   
        init_staffs_table(path)
        dbase=sqlite3.connect('gatikayantra.db');
        db=dbase.cursor()        
        db.execute('select name from staffs')
        staffs=db.fetchall()
        db.execute('select * from sections')
        sections=db.fetchall()
        sheet=len(sections)+7
        print 'started reading idividual staff tt'
        for name in staffs:
            name=''.join(name)
            #print 'wait, reading '+name+' TT'
            pyexcel.initialise(path,sheet)
            rowmax=pyexcel.getRowSize()
            row=1
            idnum=1
            while row<rowmax:
                typ=1
                while typ<4:
                    data=pyexcel.getRow(row)
                    rowdata=data[1:]
                    i=0
                    for a in rowdata:
                        if a==None or a=='':
                            rowdata[i]='free'
                        i+=1
                    data1=[idnum,typ]+rowdata+['free']
                    data1=tuple(data1)
                    statement='insert into _'+name+' values(?,?,?,?,?,?,?,?,?)'
                    db.execute(statement,data1)
                    dbase.commit()
                    typ+=1
                    row+=1
                
                idnum+=1
            sheet+=1
        db.close()
        print 'Done Lect TT'
        return True
    except:
        print 'exception in prepare_staff_timetable'
        db.close() 
        return False
        


def init_staffs_table(path):
    try:
        read_staffs_list(path)
        dbase=sqlite3.connect('gatikayantra.db');
        db=dbase.cursor()
        db.execute('select name from staffs')
        staffs=db.fetchall()
        print 'wait, initializing individual staff TT'
        for name in staffs:
            name=''.join(name)
            db.executescript('drop table if exists _'+name)
            dbase.commit()
            statement='''create table _'''+name+''' (id int,typ int,monday text,tuesday text,wednesday text,thursday text,friday text,saturday text,sunday text);'''
            db.execute(statement)
            dbase.commit()
        print 'individual staff tt initaialsed'
        db.close()
        return True

    except:
        print 'exception in init_staffs_table()'
        db.close()
        return False
    
def read_staffs_list(path):
    try:
        dbase=sqlite3.connect('gatikayantra.db');
        db=dbase.cursor()
        sheet=5
        pyexcel.initialise(path,sheet)
        rowmax=pyexcel.getRowSize()
        db.executescript('drop table if exists staffs')
        dbase.commit()
        db.execute('''create table staffs (id integer primary key,name text,password text);''')
        dbase.commit()
        row=1
        while  row<rowmax:
            rowdata=pyexcel.getRow(row)
            data=(None,rowdata[0],'admin')
            db.execute('insert into staffs values(?,?,?)',data)
            dbase.commit()
            row+=1
        db.close()
        print 'done reading staffs list'
        return True
    
    except:
        db.close()
        print 'exception in read_staff_list'
        return False

        
    
        
