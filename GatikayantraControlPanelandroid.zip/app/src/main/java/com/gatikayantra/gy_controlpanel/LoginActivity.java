package com.gatikayantra.gy_controlpanel;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.audiofx.BassBoost;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    Button loginButton;
    EditText username,password;

    serverComm mycom=new serverComm();
    String ipaddServer="";
    String ipaddbell="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username=(EditText)findViewById(R.id.username);
        password=(EditText)findViewById(R.id.password);
        loginButton=(Button)findViewById(R.id.button);

        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        ipaddServer=settings.getString("serverIP","");
        ipaddbell=settings.getString("bellIP","");

    }

    public void verifyPass(View view) {

        String usernameAut = username.getText().toString();
        String passwordAut = password.getText().toString();

        String j = mycom.getText(ipaddServer, "usr " + usernameAut + " " + passwordAut);
        if (j.equals("T\n")) {
            Intent intent1 = new Intent(view.getContext(), ControlScreenActivity.class);
            intent1.putExtra("mainServerIP", ipaddServer);
            intent1.putExtra("bellIP", ipaddbell);

            startActivity(intent1);

            finish();
}
        else{

            Toast.makeText(getApplicationContext(),"Wrong Credentials... \n Restart the app and ttry again ", Toast.LENGTH_SHORT)
                    .show();

        }
    }

    public void settingsActicate(View view) {

        Intent intent1 = new Intent(view.getContext(), SettingsActivity.class);


        startActivity(intent1);
    }

    public void wirelessBell(View view) {
        Intent intent1 = new Intent(view.getContext(), ManualBellActivity.class);
        intent1.putExtra("mainServerIP", ipaddServer);
        intent1.putExtra("bellIP",  ipaddbell);

        startActivity(intent1);
    }
}


