import gydb
import time

def tostring(lst,typ):
    data=''
    for a in lst:
        data=data+''.join(a)+typ
    return data[0:len(data)-1]

def search_name(usn,sec):
    try:
        statement='select name from _'+sec.strip('\n')+'sdb where usn=?'
        #print statement,usn,sec
        data=gydb.opendbone(statement,usn)
        if data!=None:
            return data
        else:
            return False
        
    except:
        return False

def get_sec_sub(sec):#for 'get_subject'
    try:
        sec1='_'+sec
        statement='select '+sec1+' from subjects'
        print statement
        subjects=gydb.opendball(statement)
        subjects=tostring(subjects,' ')
        return subjects
    except:
        return 'F'


def get_student_marks(usn,sec,sub):#for get_marks
    try:
        student_details=gydb.opendbone('select * from _'+sec+'sdb where usn=?',usn)
        allsubmarks=student_details[2:]
        index=sub*4
        required_sub_marks=allsubmarks[index:index+5]
        print required_sub_marks
        '''marks=''
        for a in required_sub_marks:
            marks=marks+str(a)'''
        return required_sub_marks
    except:
        return 'F'
