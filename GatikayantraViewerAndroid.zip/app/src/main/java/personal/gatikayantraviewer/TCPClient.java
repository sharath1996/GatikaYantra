package personal.gatikayantraviewer;

import android.os.AsyncTask;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;







public class TCPClient extends AsyncTask<Void, Void, String> {

    String dstAddress;
    int dstPort;
    String response = "", INmessage;
    TextView textResponse, textResponse2;
    public PrintWriter out;
    String message;
    Socket socket = null;
    TCPClient(String addr, int port, String inputMessage) {
        dstAddress = addr;
        dstPort = port;
        //this.textResponse = textResponse;
        INmessage=inputMessage;

    }

    @Override
    protected String doInBackground(Void... arg0) {



        try {
            socket = new Socket("192.168.0.105", 5000);
            socket.setSendBufferSize(1024);
            socket.setReceiveBufferSize(1024);

        } catch (UnknownHostException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            response = "H";
            return response;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            response = "H";
            return response;
        }
        try {
            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
            out.write(INmessage+"\n");
            out.flush();
            response="output";

        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            //while(true)
            message =in.readLine()+System.getProperty("line.separator");
            response=message;
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();

            response="H ";
            return response;
        }


        finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    response="H";
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    return response;
                }
            }
        }
        return response;
    }

    @Override
    protected void onPostExecute(String result) {
        //textResponse.setText(response);


        super.onPostExecute(result);
    }

}



















