 
import socket
import sys
from thread import start_new_thread
import time
import timetableops
import modeops
import timelistops
import sqlite3
import gydb
#import readDbase
#import studentDB
#import staffsDB
import bellops
import studentops
import lectops
import gybasicops
import timevalidity
import messenger

def tostring(lst,typ):
    try:
        data=''
        for a in lst:
            data=data+''.join(a)+typ
        return data[0:len(data)-1]
    except:
        print 'exception in to GY.string'
        return 0

def to_digits(var,typ):
    try:
        reply=var.split(typ)
        i=0
        for a in reply:
            reply[i]=int(a)
            i+=1
        return reply
    except:
        print 'exception in GY.to_digits'
        return var
            
def progress_status(val):
    try:
        resp=gybasicops.progress_status(val)
        return resp
    except:
        print 'exception in GY.progress_status'
        return 0

def login(x):
    try:
        idnum=1
        usrpsw=gydb.opendbone('select username,password from login where id=?',idnum)
        y=x.split()
        namepsw=y[1:]
        if namepsw==[] or namepsw[0]==[] or namepsw[1]==[]:
            conn.send("F\n")
        
        elif (usrpsw[0]==namepsw[0] and usrpsw[1]==namepsw[1]):
            conn.send("T\n")
        
        else:
            conn.send("F\n")
    except:
        print "exception GY.login"
        conn.send("F\n")


def changepsw(x):
    try:
        y=x.split()
        namepsw=y[1:]+[1]
        if gydb.updatedb("update login set username=?,password=? where id=?",namepsw):
            conn.send("T\n")
        else:
            conn.send("F\n")
    except:
        print "exception in GY.changepsw"
        conn.send("F\n")

def mode():
    modes='Normal Internals Exam Holiday'
    conn.send(modes+'\n')
    #print "sucess"

def roomlist():
    try:
        rooms=gydb.opendball('select * from rooms')
        data=tostring(rooms,' ')
        conn.send(data+"\n")
        #print "sucess2"
    except:
        conn.send("Data erased\n")
        print "exception in GY.roomlist" 
    
def sections():
    try:
        secs=gydb.opendball('select * from sections')
        data=tostring(secs,' ')
        conn.send(data+"\n")
        #print data
        #print "sucess1"
    except:
        conn.send("Data erased\n")
        print "exception in GY.sections"

def getstarttimelist(x):
    try:
        resp=timelistops.read_timelist('starttime',x)
        if resp:
            resp=tostring(resp,' ')
            conn.send(resp+'\n')
        else:
            conn.send('TF\n')
    except:
        print 'exception in GY.getstarttimelist' 

def getendtimelist(x):
    try:
        resp=timelistops.read_timelist('endtime',x)
        resp=tostring(resp,' ')
        if resp:
            conn.send(resp+'\n')
        else:
            conn.send('TF\n')
    except:
        print 'exception in GY.getendtimelist' 

def editlist(x):#for editT
    try:
        resp=timelistops.edit_timelist(x)
        if resp:
            conn.send('T\n')
        else:
            conn.send('TF\n')
    except:
        print 'excpetion in GY.editlist'
        conn.send('TF\n')
        
def addlist(x):# for addT
    try:
        resp=timelistops.add_timelist(x)
        if resp:
            conn.send('T\n')
        else:
            conn.send('TF\n')
    except:
        print 'exception in GY.addlist'
        conn.send('TF\n')

def roomtimetable(x):#for lctq
    try:
        period=timetableops.get_room_period(x)
        if period!=False:
            period=tostring(period[1:],'-')
        else:
            period='Timetable-doesnt_exist'
        conn.send(period+'\n')
    except:
        print 'exception in GY.roomtimetable'
        conn.send('F-F-F\n')

    
def edit_timetable(x):#for lects
    try:
        resp1=timetableops.edit_room_timetable(x)
        resp2=timetableops.edit_sec_timetable(x)

        if resp1 and resp2:
            conn.send('T\n')
        else:
            conn.send('F\n')
    except:
        print 'exception in GY.edit_timetable'
        conn.send('F\n')

def rttbl(x):#for qeryR
    try:
        query=x.split()
        day=query[3]#DAY
        timeindex=query[2]#timeindex
        room=query[1]#room
        data=query[0]+' '+day+' '+timeindex+' '+room
        period=timetableops.get_room_period(data)
        
        if period:
            period=tostring(period,'-') 
            conn.send(period+'\n')
        else:
            conn.send('Timetable-doesnot-exist\n')
    except:
        print 'exception in GY.rttbl'
        conn.send('F-F-F\n')

def sttbl(x):
    try:
        period=timetableops.get_sec_period(x)
        if period==None:
            conn.send('Timetable-doesnot-exist\n')

        else:
            period=tostring(period,'-')
            conn.send(period+'\n')
    except:
        print 'exception in GY.sttbl'
        conn.send('F-F-F\n')


def lectlist():#for lectname
    try:
        lecturers=lectops.get_lectlist()
        conn.send(lecturers+"\n")    
    except:
        print 'exception in GY.lectlist'
        conn.send('F-F-F\n')
        
def editllist(x):#for editlect
    try:
        flag=lectops.edit_lect_list(x)   
        if flag:
            conn.send("T\n")
        else:
            conn.send("F\n")
    except:
        conn.send("F\n")
        print 'exception in GY.editllist'

def addlect(x):#for addlect
    try:
        resp=lectops.add_lect(x)
        if resp:
            conn.send("T\n")
        else:
            conn.send("F\n")
    except:
        print 'exception in GY.addlect'    
        conn.send("F\n")

def announcement(x):
    try:
        conn.send("T\n");
        y=x.split(":")
        faculty=y[2].strip('\n')
        message=y[3].strip('\n')
        room=y[1].strip('\n')
        send_notice(room+":"+faculty+":"+message)
    except:
        print 'exception in GY.announcement'


def get_details(btyp):
    try:
        rooms=gydb.opendball('select * from rooms')
        tindex=bellops.get_session_num()
        day=time.strftime("%A",time.localtime())
        day=day.lower()
        message={1:"-free-Short Break-be back @ 10:45AM",2:"-free-Lunch Break-be back @ 2:30PM",3:"-free-End of the day-Thank You"}
        for room in rooms:
            room=''.join(room)
            if btyp=='LB':
                statement='select '+day+' from '+room+' where id=?'
                period=gydb.opentimetable(statement,tindex)
                if period!=None and period!=[]:
                    period=tostring(period,'-')
                    period1=room+"-"+period
                else:
                    period1=room+"-free-free-free"
            else:
                if tindex%3==0:
                    period1=room+message[tindex/3]
                else:
                    period1=room+'-free-Session Ends-in 5 mins'
            
            sending_data(period1,room)
    except:
        print 'exception in GY.get_details'

def send_notice(x):
    try:
        y=x.split(":")
        room=y[0].upper()
        faculty=y[1]
        message=y[2]
        data="message-"+faculty+" : "+message
        sending_data(data,room)
    except:
        print 'exception in send_notice'    

def sending_data(x,room1):
    try:
        room=room1.upper()
        if (room1.lower()!='general'):
            statement='select ipaddrs from device_ips where device=?'
            host=gydb.opendbone(statement,room)
            host=''.join(host)
            port=6000
            #print "connecting to : ",room,host
            resp=send_to(host,port,x)
            if resp:
                gybasicops.glow_room_led([room,True])
                
        else:
            statement='select ipaddrs from device_ips'
            HOST=gydb.opendball(statement)
            port=6000
            statement1='select device from device_ips'
            rooms=gydb.opendball(statement1)
            i=1
            for host in HOST[1:]:
                room=rooms[i]
                room=''.join(room)
                host=''.join(host)
                #print "connecting to : ",room,host
                resp=send_to(host,port,x)
                if resp:
                    gybasicops.glow_room_led([room,True])
        return 1
    except :
        print 'exception in Gy.sending_data to: ',room
        gybasicops.glow_room_led([room,False])
        return 0

def send_to(host,port,data):
    try:
        c=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        c.connect((host,port))
        c.send(data+'\n')
        c.close()
        #print data
        return 1
    except:
        print 'error in GY.send_to ,host: '+host
        c.close()
        room=timetableops.rm_frm_ip(host)
        gybasicops.glow_room_led([room,False])
        return 0

def flogin(x):#for aut and ver
    try:
        resp=lectops.lect_login(x)
        conn.send(resp)
    except:
        print 'exception in GY.flogin'
        conn.send('F\n')
   
def fchangepsw(x):#for Fchange
    try:
        resp=lectops.lect_changepsw(x)
        conn.send(resp)
    except:
        print 'exception in GY.fchangepsw'
        conn.send('F\n')

def calender(x):#for cal
    try:
        x=x.split()
        date=x[1]
        resp=modeops.check_mode(date)
        mode=resp.strip('time')
        conn.send(mode+'\n')
    except:
        print 'exception in GY.calender'
        conn.send('F\n')

def set_calender_mode(x):
    try:
        x=x.split()
        date=x[2]
        mode=x[1].lower()
        resp=modeops.set_edit_mode(date,mode)
        if resp:
            conn.send('T\n')
        else:
            conn.send('F\n')
    except:
        print 'exception in GY.set_calender_mode'
        conn.send('F\n')

def read_from_drive():
    try:
        conn.send('T\n')
        gybasicops.complete_update('software')
    except:
        print 'exception in GY.read_from_drive'

'''def update_student_db():
    if studentsDB.updatedb():
        conn.send('T\n')
    else:
        conn.send('F\n')'''

def search_student(x):
    try:
        y=x.split(' ')
        data=studentops.search_name(y[1],y[2])
        if data:
            data2=''.join(data)
        else:
            data2='F'
        print data2
        conn.send(data2+'\n')
    except:
        print 'exception in GY.search_student'
        conn.send('F\n')

def get_sub(x):#for 'get_subject'
    try:
        x=x.split()
        sec=x[1]
        sec_subjects=studentops.get_sec_sub(sec)
        conn.send(sec_subjects+'\n')
    except:
        print 'exception in GY.get_sub'
        conn.send('F\n')

def get_marks(x):#for get_marks
    try:
        x=x.split()
        usn=x[1]
        sec=x[2]
        sub=int(x[3])
        resp=studentops.get_student_marks(usn,sec,sub)
        resp=tostring(resp,'-')
        print resp
        conn.send(resp+'\n')
    except:
        print 'exception in GY.get_marks'
        conn.send('F\n')

def lect_tt(x):#for lect_timetable
    try:
        period=lectops.get_lect_timetable(x)
        conn.send(period+'\n')
    except:
        print 'exception in GY.lect_tt'
        conn.send('F\n')

def server_config(address):#not tested
    try:
        day=time.strftime("%A",time.localtime()).lower()
        room=timetableops.rm_frm_ip(address)
        period=timetableops.server_config_tt(room,day)  
        #print address,period1
        send_to(address,6000,period)
    except:
        print 'excepton inserver_config'
        send_to(address,6000,'F-F-F-F')
        
def ring_bell(dur):
    try:
        if dur=='SB':
            bellnum=bellops.get_session_num()
            if bellnum%3==0:
                dur='LB'
        adress="192.168.0.101"
        port=5000
        send_to(adress,port,dur)
    except:
        print "error reaching bell"

def gy_wtsap(x):
    try:
        resp=messenger.rcv_msg(x)
        print resp
        conn.send('T\n')
    except:
        conn.send('F\n')
        print 'error in GY.gy_wtsap'
        return 0      

def wakeup_tabs(tym):
    try:
        if (tym>="10:15:00" and tym<="10:44:00") or (tym>="13:30:00" and tym<="14:29:00"):
            get_details('SB')
        else:
            get_details('LB')
    except:
        get_details('LB')
        print 'exception in GY.wakeup_tabs'

def print_time():
    try:
        t1=time.strftime("%H:%M:%S",time.localtime())
        date=time.strftime("%d/%m/%Y",time.localtime())
        day=time.strftime("%A",time.localtime())
        tablename=modeops.check_mode(date)
        if (tablename!="holiday" and day.lower()!='sunday'):
            timevalidity.switching_time(t1)
            gybasicops.switching_pin_status()
            stimelist=gydb.opendball('select starttime from '+tablename)
            etimelist=gydb.opendball('select endtime from '+tablename)
            bellops.init_bellnum(stimelist,t1)
            wakeup_tabs(t1)
            while 1:
                progress=progress_status('check').lower()
                if progress!='true':
                    t1=time.strftime("%H:%M:%S",time.localtime())
                    for tym in stimelist:
                        tym1=''.join(tym)
                        tym1=to_digits(tym1,':')#returns [hh,mm,ss]
                        t1=to_digits(t1,':')#returns [hh,mm,ss]
                        if (t1[0]==tym1[0] and t1[1]>=tym1[1] and t1[1]<=tym+2):
                            bellops.init_bellnum(stimelist,t1)
                            tym=''.join(tym)
                            ring_bell('LB')
                            get_details('LB')
                            print "bell now first: "+tym1
                            time.sleep(180)
                        
                    for tym in etimelist:
                        tym1=''.join(tym)
                        tym1=to_digits(tym1,':')#returns [hh,mm,ss]
                        t1=to_digits(t1,':')#returns [hh,mm,ss]
                        if (t1[0]==tym1[0] and t1[1]>=tym1[1] and t1[1]<=tym+2):
                            bellops.init_bellnum(stimelist,t1)
                            print "bell now second: "+tym1
                            ring_bell('SB')
                            get_details('SB')
                            time.sleep(149)#2 mins and 29 sec sleep
        else:
            gybasicops.ring_buz(2)
            gybasicops.blink_led(4)
            gybasicops.clear_gpio()
            s.close()
            print "holiday"
            sys.exit(0) 

    except KeyboardInterrupt:
        gybasicops.clear_gpio()
        s.close()
        print "manual override"
        sys.exit(0)       
    except:
        print 'exception in GY.print_time'
        #start_new_thread(print_time,())
    

def client_thread(conn,address):
        x=conn.recv(1024)
        print "recieved data :"+x
        progress=progress_status('check').lower()
        #print progress

        if progress=='true':
            conn.send('P\n')        

        elif "usr" in x:
            login(x)

        elif "mod" in x:
            mode()

        elif "stl" in x:
            getstarttimelist(x)
    
        elif "etl" in x:
            getendtimelist(x)

        elif (x.find("appq",0,5)==0):
            rttbl(x);
            
        elif "editT" in x:
            editlist(x)

        elif "addT" in x:
            addlist(x)

        elif (x.find("lctq",0,4)==0):
            roomtimetable(x)

        elif (x.find("lects",0,5)==0):
            edit_timetable(x)

        elif (x.find("rml",0,3)==0):
            roomlist()

        elif (x.find("sec",0,3)==0):
            sections()
            
        elif (x.find("queryR",0,6)==0):
            rttbl(x);

        elif (x.find("queryS",0,6)==0):
            sttbl(x);
        
        elif (x.find("day",0,3)==0):
            conn.send("Monday Tuesday Wednesday Thursday Friday Saturday Sunday\n");

        elif (x.find("announce",0,8)==0):
            announcement(x)

        elif (x.find("lectName",0,8)==0):
            lectlist();

        elif (x.find("editlect",0,9)==0):
            editllist(x)

        elif (x.find("addlect",0,8)==0):
            addlect(x)

        elif (x.find("aut",0,3)==0):
            flogin(x)

        elif (x.find("ver",0,3)==0):
            flogin(x)
        
        elif (x.find("change",0,6)==0):
            changepsw(x)

        elif (x.find("Fchange",0,7)==0):
            fchangepsw(x)

        
        elif (x.find("setCal",0,7)==0):
            set_calender_mode(x)
        

        elif (x.find("cal",0,3)==0):
            calender(x)

        elif(x.find("read_db",0,8)==0):
            read_from_drive()

        elif(x=='update_studentdb'):
            conn.send('F\n')
            #update_student_db()

        elif(x.find('search_student',0,14)==0):
            #conn.send('disabled\n')
            search_student(x)
        
        elif(x.find('get_subjects',0,13)==0):
            #conn.send('disabled\n')
            get_sub(x)

        elif(x.find('get_marks',0,10)==0):
            #conn.send('disabled\n')
            get_marks(x)

        elif(x.find('lect_timetable',0,14)==0):
            lect_tt(x)

        elif(x.find('serveronline',0,13)==0):
            conn.send('T\n')
            conn.close()
            server_config(address)

        elif(x.find('messageFrom',0,14)==0):
            #conn.send('T\n')
            gy_wtsap(x)
        else:
            conn.send("F\n")
            conn.close()

statement='select ipaddrs from device_ips where device=?'
device='SERVER'
data=gydb.opendbone(statement,device)
if data==None:
    data=("192.168.0.105",)
data=''.join(data)
print data

'''data=socket.gethostname()
print 'ip adress of GY: ',data'''

SHOST = data   
SPORT = 5000 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    s.bind((SHOST, SPORT))
    
except socket.error as msg:
    print 'Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
    s.close()
    sys.exit()

current_time=time.strftime("%H:%M:%S",time.localtime())
timevalidity.switching_time(current_time)
gybasicops.setup_hardware()
start_new_thread(print_time,())
s.listen(25)

try:
    while 1:
        #wait to accept a connection - blocking call
        conn, addr = s.accept()
        print 'Connected with ' + addr[0] + ':' + str(addr[1])   
        start_new_thread(client_thread, (conn,addr[0]))
except KeyboardInterrupt:
    gybasicops.clear_gpio()
    s.close()
    print "manual override"
    sys.exit(0)
    
s.close()
gybasicops.clear_gpio()
