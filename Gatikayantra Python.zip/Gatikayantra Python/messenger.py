from timevalidity import get_time 

def rcv_msg(data):#messageFrom:sender_name:reciever_name:message
    try:
        data=data.split(':')
        src=data[1]
        dst=data[2]
        new_msg=data[3]
        #resp=msg_status(dst,'update')
        #if resp:
        save_msg(src,dst,new_msg)
        return 1
        #else:            
    except:
        print 'exception in messenger.rcv_msg'
        return 0

def read_msg(dst):
    try:
        fo=open(dst+'.txt','r+')
        msg=fo.read()
        fo.close()
        #print msg
        if msg=='' or msg.lower()=='false':
            msg='no message'
        else:
            fo=open(dst+'.txt','w+')
            fo.write('')
            fo.close()
        return msg
    except:
        print 'error in msssenger.read_msg'
        return 'no message'
    
def msg_status(dst,op):
    #try:
        fo=open('message_status','w+')
        status=fo.read()
        if op=='update':
            status=status+'\n'+dst
            fo.write(status)
            fo.close()
            status=True   
        return status
'''except:
        print 'exception in messenger.update_msg_status'
        fo.close()
        return False'''

def save_msg(src,dst,new_msg):
    try:
        #time=get_time('time')
        try:
            fo=open(dst+'.txt','r+')
            old_msg=fo.read()
            fo.close()
        except:
            fo=open(dst+'.txt','w+')
            old_msg=''
            fo.close()
        if old_msg!='' or old_msg.lower()!='false':
            msg=old_msg+'#'+src+':'+new_msg.strip('\n')
        else:
            msg=src+':'+new_msg
        fo=open(dst+'.txt','w+')
        fo.write(msg)
        #print msg
        fo.close()
        return 1
    except:
        print 'exception in msessenger.save_msg'
        return 0
            
