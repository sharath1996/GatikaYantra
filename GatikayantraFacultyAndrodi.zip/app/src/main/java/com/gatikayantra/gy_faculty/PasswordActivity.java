package com.gatikayantra.gy_faculty;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class PasswordActivity extends AppCompatActivity {
    Button updatePass;
    EditText password, verifypassword;
    TextView fac_name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);
        updatePass=(Button)findViewById(R.id.updatepassword);
        password=(EditText)findViewById(R.id.password_entry);
        verifypassword=(EditText)findViewById(R.id.verifPass);
        fac_name=(TextView) findViewById(R.id.fac_name_PC);
       final serverComm myserver=new serverComm();

        Intent intent = getIntent();
        final String fname=intent.getExtras().getString("Fname");
        final String fullname=intent.getExtras().getString("FullName");
        final String IPadd=intent.getExtras().getString("IPAddress1");
        fac_name.setText(fullname);



       updatePass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pass=password.getText().toString();
                String pass2=verifypassword.getText().toString();
                if(pass.equals(pass2)){
                    int j=myserver.getResponse(IPadd,"Fchange "+fname+" "+pass);
                    Toast.makeText(getApplicationContext(), "Password updated", Toast.LENGTH_SHORT)
                            .show();
                }
                else Toast.makeText(getApplicationContext(),"Password do not match", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
