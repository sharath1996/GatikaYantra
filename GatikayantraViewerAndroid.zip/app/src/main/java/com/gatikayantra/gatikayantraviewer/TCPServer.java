package com.gatikayantra.gatikayantraviewer;

/**
 * Created by sharath on 28/12/16.
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.Buffer;

import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;



public class TCPServer extends AsyncTask<Void, Void, String> {

    String dstAddress;
    int dstPort;
    String response = "", INmessage;
    TextView room,faculty,subject,section;
    public PrintWriter out;
    String finalMessage;
    ServerSocket socket = null;
    Socket mySocket;
    boolean gotResponse =true;

    private static BufferedReader in;

    private static OutputStream outputStream;
    Handler handler = new Handler();
    Socket s;


    TCPServer( int port, TextView room1, TextView subject1, TextView faculty1, TextView section1 ,String reply1,Socket sock) {

        dstPort = port;
        room=room1;
        section=section1;
        subject=subject1;
        faculty=faculty1;
        section=section1;
        INmessage=reply1;
        mySocket=sock;
        Log.w("server", "FLAG!");
        //this.textResponse = textResponse;


    }
    @Override

    protected String doInBackground(Void... params) {



        try {


            mySocket.setReceiveBufferSize(1024);


            Log.w("server","Client Accepted");
            mySocket.setSendBufferSize(1024);



            try {
                BufferedReader  in = new BufferedReader(new InputStreamReader(mySocket.getInputStream()));
                //while(true)
                finalMessage =in.readLine()+System.getProperty("line.separator");
                response=finalMessage;
                Log.w("server", "READ");

            } catch (IOException e) {
                e.printStackTrace();

                response="H ";
                return response;
            }

            try {
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(mySocket.getOutputStream())), true);
                out.write("T"+"\n");
                out.flush();
                response="output";
                Log.w("server", "OTPUT");

            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } finally {
            if (s != null) {
                try {

                    mySocket.close();

                } catch (IOException e) {
                    response="H";
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    return response;
                }
            }
        }

        return "t\n";
    }




    @Override
    protected void onPostExecute(String result) {
        //textResponse.setText(response);
        String[] reply=finalMessage.split(" ");
        Log.w("server","on progress called");
        Log.w("server",reply[0]+reply[1]+reply[2]+reply[3]);
        room.setText(reply[0]);
        section.setText(reply[1]);
        faculty.setText(reply[2]);
        subject.setText(reply[3]);
        INmessage="done";

        super.onPostExecute(result);

    }

}