package com.gatikayantra.gy_controlpanel;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class GeneralAnnouncementActivity extends AppCompatActivity {
EditText message,facName;
    String ipaddServer="";
    String ipAdressClient="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_announcement);
        message=(EditText)findViewById(R.id.announceText);
        facName=(EditText)findViewById(R.id.facName);
        final Intent intent=getIntent();
        ipAdressClient=intent.getExtras().getString("bellIP");
        ipaddServer=intent.getExtras().getString("mainServerIP");
    }

    public void AnnounceFunction(View view) {
        serverComm mycomm=new serverComm();

        mycomm.getResponse(ipaddServer,"announce:general:"+facName.getText().toString()+":"+message.getText().toString());
        Toast.makeText(getApplicationContext(),"Announced ", Toast.LENGTH_SHORT)
                .show();

        message.setText("");
        facName.setText("");
    }
}
