import sqlite3
import pyexcel
import math

def read_sdb(path):#tested ok
    try:
        if create_sdb():
            dbase=sqlite3.connect('gatikayantra.db')
            db=dbase.cursor()
            db.execute('select * from sections')
            sections=db.fetchall()
            sheet=2+len(sections)#sheet 0 to 3 other data and 3 onwards section timetble so, student sdb starts from 3+len(sections)-1
            for sec in sections:#reading data sectionwise
                sec=''.join(sec)
                pyexcel.initialise(path,sheet)
                rowmax=pyexcel.getRowSize()
                row=1#skip first row
                while row<rowmax:#read data rowwise i.e usn-wise
                    rowdata=pyexcel.getRow(row)
                    i=2
                    for a in rowdata[2:]:
                        if a=='' or a==None:
                            rowdata[i]=0
                        else: 
                            rowdata[i]=math.floor(a)
                        i+=1
                    rowdata=tuple(rowdata)
                    statement='insert into _'+sec+'sdb values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
                    db.execute(statement,rowdata)
                    dbase.commit()
                    row+=1
                print 'reading sdb'
                sheet+=1
            db.close()
            return True
        
        else:
            return False

    except:
          return False  

def create_sdb():#creates empty stuedents database table for each section
    try:#tested ok
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        db.execute('select * from sections')
        sections=db.fetchall()
        for sec in sections:
            sec=''.join(sec)
            db.executescript('drop table if exists _'+sec+'sdb')
            #sdb (usn text primary key,name text,sub1t1 int,sub1t2 int,sub1t3 int,sub1a int,sub2t1 int,sub2t2 int,sub2t3 int,sub2a int,sub3t1 int,sub3t2 int,sub3t3 int,sub3a int,sub4t1 int,sub4t2 int,sub4t3 int,sub4a int,sub5t1 int,sub5t2 int,sub5t3 int,sub5a int,sub6t1 int,sub6t2 int,sub6t3 int,sub6a int)'''
            statement='''create table _'''+sec+'''sdb (usn text,name text,sub1t1 int,sub1t2 int,sub1t3 int,sub2t1 int,sub2t2 int,sub2t3 int,sub3t1 int,sub3t2 int,sub3t3 int,sub4t1 int,sub4t2 int,sub4t3 int,sub5t1 int,sub5t2 int,sub5t3 int,sub6t1 int,sub6t2 int,sub6t3 int)'''
            db.execute(statement)
            dbase.commit()
            print 'wait csdb'
        db.close()
        return True

    except:
        return False    
        


def subject_db():#tested ok
    try:
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        db.execute('select * from sections')
        sections=db.fetchall()
        statement='''create table subjects ('''
        for sec in sections:
            sec=''.join(sec)
            statement=statement+'_'+sec+' text,'
        statement1=statement[0:len(statement)-1]+''')'''
        db.execute(statement1)
        dbase.commit()
        print statement1
        sheet=3
        pyexcel.initialise(path,sheet)
        rowmax=pyexcel.getRowSize()
        row=1
        while row<rowmax:
            data=pyexcel.getRow(row)
            print 'wait sub'
            '''statement1='insert into subjects values('
            for a in data:
                statement1=statement1+'?,'
            statement=statement[0:len(statement1)-1]+')''''
            statement='insert into subjects values(?,?,?,?,?,?,?,?)'
            data=tuple(data)
            db.execute(statement,data)
            dbase.commit()
            row+=1
        db.close()
        return True

    except:
        return False
    
            
