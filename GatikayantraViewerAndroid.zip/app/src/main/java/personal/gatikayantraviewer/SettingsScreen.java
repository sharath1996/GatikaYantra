package personal.gatikayantraviewer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class SettingsScreen extends AppCompatActivity {
    EditText user,password,ipadd;
    Button aut;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_screen);
        user=(EditText)findViewById(R.id.Username);
        password=(EditText)findViewById(R.id.password);
        ipadd=(EditText)findViewById(R.id.IPADRESS);




    }
}
