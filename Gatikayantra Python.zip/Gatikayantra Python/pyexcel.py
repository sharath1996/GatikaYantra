import xlrd


def initialise(str,l):
    xl_work=xlrd.open_workbook(str)
    global sheet
    sheet=xl_work.sheet_by_index(l)


def getCol(k):
    rlen=sheet.ncols
    clen=sheet.nrows
    i=0
    colSel=[]
    while(i!=clen):
        colSel=colSel+[sheet.cell_value(i,k)]
        i=i+1
    #colSelRet=colSel.split(' ')   
    return colSel

def getRow(k):
    rlen=sheet.ncols
    clen=sheet.nrows
    i=0
    rowSel=[]
    while(i!=rlen):
        rowSel=rowSel+[sheet.cell_value(k,i)]
        i=i+1
    #rowSelRet=rowSel.split(' ')
    return rowSel

def getRowSize():
	return sheet.nrows

def getColSize():
	return sheet.ncols





    
    
