import gydb
import timevalidity

def edit_timelist(x):
    try:
        request=x.split()
        data=request[4:]
        if (timevalidity.check(data)==False):#check_data_validity returns true if the data is in HH:MM:SS format
            return False
        
        else:
            timelistnames={'normal':"normaltime",'exam':"examtime",'internals':"internalstime"}
            y=x.split()
            mode=y[1].lower()
            statement='update '+timelistnames[mode]+' set starttime=?,endtime=? where id=?'
            data=y[4:]+[str(int(y[2])+1)]
            if mode!='holiday':
                resp=gydb.updatedb(statement,data)
                return resp
            else:
                return False
        
    except:
        return False


def add_timelist(x):
    try:
        request=x.split()
        data=request[2:]
        if (timevalidity.check(data)==False):#check returns true if the data is in HH:MM:SS format
            return False
        
        else:
            y=x.split()
            mode=y[1].lower()
            timelistnames={'normal':"normaltime",'exam':"examtime",'internals':"internalstime"}
            if mode!='holiday':
                statement='insert into '+timelistnames[mode]+' values(?,?,?)'
                data=y[2:]
                resp=gydb.addtodb(statement,data)
                if resp!=None:
                    return True
                else:
                    return False
                
            else:
                return False
    except:
        return False

def read_timelist(tabname,x):
    try:
        timelistnames={'normal':"normaltime",'exam':"examtime",'internals':"internalstime"}
        x=x.split()
        mode=x[1].lower()
        if mode=='holiday':
            conn.send('Holiday\n')

        else:
            statement='select '+tabname+' from '+timelistnames[mode]
            print statement
            resp=gydb.opendball(statement)
        print resp
        return resp
        
    except:
        return False
    
