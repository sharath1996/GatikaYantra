import gydb

def init_bellnum(stimelist,t1):
    try:
        fo=open('timetrack.txt','w+')
        bellnum=fo.read()
        k=1
        flag=0
        for tym in stimelist:
            tym=''.join(tym)
            if tym==t1:
                bellnum=str(k)
                flag=1
                break    
            elif t1<tym:
                bellnum=str(k-1)
                flag=1
                break
            '''elif t1>tym:
                bellnum=str(k)
                break '''       
            k+=1
        if flag==0:
            bellnum=str(k-1)
        #print "bellnum",bellnum
        fo.write(bellnum)
        fo.close()
        return 1
    except:
        fo.close()
        print 'exception in bellops.init_bellnum'
        return 0

def get_session_num():
    try:
        fo=open("timetrack.txt","r+")
        val=fo.read()
        fo.close()
        if val!='' and val>='0':
            val1=int(val)
        else:
            val1=0
        return val1
    except:
        print 'error in get_session_num'
        return 0
