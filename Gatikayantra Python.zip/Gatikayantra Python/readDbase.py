import sqlite3
import pyexcel
import dbsetup

def prepare_timelist(path):#tested ok
    try:
        print dbsetup.create_db()
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        time_lists=['normaltime','internalstime','examtime']
        sheet=0
        for TL in time_lists:
            pyexcel.initialise(path,sheet)
            rowmax=pyexcel.getRowSize()
            print rowmax
            row=1
            while row<rowmax:
                data=pyexcel.getRow(row)
                i=0
                for a in data:
                    data[i]=a.strip('t')
                    i+=1
                data1=[row]+data
                data1=tuple(data1)
                statement='insert into '+TL+' values(?,?,?)'
                #print data1
                db.execute(statement,data1)
                dbase.commit()
                row+=1
            sheet+=1
            print 'Done Time list: ',TL
        db.close()
        print 'Done reading all timelists'
        return True

    except:
        print 'exceptions in preparing timelist'
        return False

def read_sec_list(path):
    try:
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        sheet=3
        pyexcel.initialise(path,sheet)

        sec=pyexcel.getCol(0)
        for a in sec[1:]:
            if a!='sections' and a!='Sections' and a!='SECTIONS':
                db.execute('insert into sections values(?)',(a,))
                dbase.commit()
        print sec
        db.close()
        return True

    except:
        print 'exception in read_sec_list'
        return False

def read_room_list(path):
    try:
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        sheet=4
        pyexcel.initialise(path,sheet)

        rooms=pyexcel.getCol(0)
        for a in rooms[1:]:
            db.execute('insert into rooms values(?)',(a,))
            dbase.commit()
        print rooms
        db.close()
        return True

    except:
        print 'exception in read_room_list'
        return False



def prepare_timetable(path):#tested ok
    try:
        create_empty_sec_table()
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        db.execute('select * from sections')
        sections=db.fetchall()
        sheet=7
        print 'wait, reading sec TT'
        for sec in sections:
            sec=''.join(sec)
            pyexcel.initialise(path,sheet)
            idnum=1
            rowmax=pyexcel.getRowSize()
            row=1
            while row<rowmax:
                typ=1
                while typ<4:
                    data=pyexcel.getRow(row)
                    i=0
                    rowdata=data[1:]
                    for a in rowdata:
                        if a=='' or a==None:
                            rowdata[i]='free'
                        i+=1
                    #print data
                    data1=[idnum,typ]+rowdata+['free']
                    data1=tuple(data1)
                    #print data1
                    statement='insert into _'+sec+' values(?,?,?,?,?,?,?,?,?)'
                    #print statement
                    db.execute(statement,data1)
                    dbase.commit()
                    typ+=1
                    row+=1

                idnum+=1
            sheet+=1
        db.close()
        print 'Done Section TT'
        if prepare_room_table(path):
            return True
        else:
            return False

    except:
        print 'exception in prepare_timetable'
        return False


def prepare_room_table(path):
    try:
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        db.execute('select * from sections')
        sections=db.fetchall()
        print 'wait- rmtbl read'
        if create_empty_table():
            sheet=7
            for sec in sections:#accessing section timetables
                sec=''.join(sec)
                pyexcel.initialise(path,sheet)
                idnum=1
                rowmax=pyexcel.getRowSize()
                row=1
                while row<rowmax:#fetches every row of section timetable
                    i=0
                    period=[]
                    while i<3:#fetches one period of entire week
                        data=pyexcel.getRow(row)
                        rowdata=data[1:]
                        k=0
                        for a in rowdata:#detecting and replacing empty cell with 'free'
                            if a==''or a==None:
                                rowdata[k]='free'
                            k+=1

                        period=period+[rowdata]
                        i+=1
                        row+=1
                    rooms=period[0]#rooms of entire week for that period
                    subjects=period[1]#subjects of entire week for that period
                    lecturers=period[2]#lectrers of entire week for that period
                    #print period
                    j=0
                    day=['monday','tuesday','wednesday','thursday','friday','saturday']
                    for a in rooms:#getting room name
                        if a!='free' and a!='FREE' and a.find('/')<1 and a.find('lab')<0 and a.find('LAB')<0 and a.find('project')<0 and a.find('PROJECT')<0:
                            typ=1
                            statement='update '+a+' set '+day[j]+'=? where id=? and typ=?'
                            data=(sec,idnum,typ)#sec for room 'a' coressponding to period 'idnum'
                            db.execute(statement,data)
                            dbase.commit()
                            typ=2
                            data=(subjects[j],idnum,typ)#subject for room 'a' coressponding to period 'idnum'
                            #print data
                            db.execute(statement,data)
                            dbase.commit()
                            typ=3
                            data=(lecturers[j],idnum,typ)#lecturer for room 'a' coressponding to period 'idnum'
                            #print data
                            db.execute(statement,data)
                            dbase.commit()
                        elif a.find('/')>0 and a.find('lab')<0 and a.find('LAB')<0 and subjects[j].find('/')>0 and lecturers[j].find('/')>0and a.find('project')<0 and a.find('PROJECT')<0:
                            r=a.split('/')
                            subs=subjects[j].split('/')
                            lects=lecturers[j].split('/')
                            count=0
                            for rm in r:
                                typ=1
                                statement='update '+rm+' set '+day[j]+'=? where id=? and typ=?'
                                data=(sec,idnum,typ)#sec for room 'rm' coressponding to period 'idnum'
                                db.execute(statement,data)
                                dbase.commit()
                                typ=2
                                data=(subs[count],idnum,typ)#subject for room 'rm' coressponding to period 'idnum'
                                #print data
                                db.execute(statement,data)
                                dbase.commit()
                                typ=3
                                data=(lects[count],idnum,typ)#lecturer for room 'rm' coressponding to period 'idnum'
                                #print data
                                db.execute(statement,data)
                                dbase.commit()
                                count+=1
                        j+=1

                    idnum+=1                    
                sheet+=1
            db.close()
            print 'Done with room TT'
            return True
        else:
            return False

    except:
        print 'exception in prepare_room_table'
        return False

def create_empty_sec_table():
    try:
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        db.execute('select * from sections')
        sections=db.fetchall()
        for sec1 in sections:
                sec=''.join(sec1)
                db.execute('''create table _'''+sec+'''
                (id int,typ int,monday text,tuesday text,wednesday text,thursday text,friday text,saturday text,sunday text);''')
                dbase.commit()
    except:
        print 'exception in create_empty_sec_table'

def create_empty_table():
    try:
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        db.execute('select * from rooms')
        rooms=db.fetchall()
        if rooms!=None:
            print 'wait - creating rmtbl'
            for a  in rooms:#creates table for each room
                a=''.join(a)
                statement='''create table '''+a+'''(id int,typ int,monday text,tuesday text,wednesday text,thursday text,friday text,saturday text,sunday text);'''
                #print 'wait'
                db.execute(statement)

            db.execute('select id from normaltime')
            rowmax=len(db.fetchall())
            print 'wait - creating empty rmtbl'
            for a in rooms:#generates empty room timetables for each room in 'room list'
                a=''.join(a)
                idnum=1
                row=1
                while row<=rowmax:#generates a single empty room timetable of 'rowmax' periods
                    typ=1
                    while typ<4:
                        i=0
                        rowdata=[]
                        while i<7:
                            rowdata=rowdata+['free']#generating 'free'  each day
                            i+=1

                        data1=[idnum,typ]+rowdata
                        data1=tuple(data1)
                        #print data1
                        statement='insert into '+a+' values(?,?,?,?,?,?,?,?,?)'
                        #print 'wait'
                        db.execute(statement,data1)
                        dbase.commit()
                        typ+=1

                    idnum+=1
                    row+=1
            db.close()
            print 'done creating empty rmtbl'
            return True
        else:
            return False

    except:
        print 'exception in create_empty_table'
        return False



def read_ipaddrs(path):
    try:
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        db.executescript('drop table if exists device_ips')
        dbase.commit()
        db.execute('''create table device_ips (device text,ipaddrs text)''')
        dbase.commit()

        sheet=0
        pyexcel.initialise(path,sheet)
        rowmax=pyexcel.getRowSize()
        row=1
        while row<rowmax:
            data=pyexcel.getRow(row)
            data=tuple(data)
            db.execute('insert into device_ips values(?,?)',data)
            dbase.commit()
            row+=1
        db.close()
        return True
    except:
        print 'exception in read_ipaddrs'
        return False
