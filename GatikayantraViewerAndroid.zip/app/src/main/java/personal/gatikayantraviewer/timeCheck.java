package personal.gatikayantraviewer;

import android.os.AsyncTask;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import android.util.Log;
/**
 * Created by Sharath on 25-09-2016.
 */
public class timeCheck extends AsyncTask<Void, Void, String> {

    String[] timeList,reply;
    String roomName="",day="",value;
    TextView faculty,sub,sectn,rooM;


    timeCheck(String timeList1, TextView lectName, TextView subject, TextView section, TextView room){
      value=timeList1;
        faculty=lectName;
        sub=subject;
        sectn=section;
        rooM=room;



    }


    @Override
    protected String doInBackground(Void... params) {
        reply=value.split(" ");




        return "true";
}
    @Override
    protected void onPostExecute(String result) {
        //textResponse.setText(response);
       rooM.setText(reply[0]);
        sectn.setText(reply[1]);
        faculty.setText(reply[2]);
        sub.setText(reply[3]);

        super.onPostExecute(result);
    }


}
