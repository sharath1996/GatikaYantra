package com.gatikayantra.gatikayantraviewer;

/**
 * Created by sharath on 28/12/16.
 */

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * Created by Sharath on 22-09-2016.
 */
public class ServerComm {

    public void serverComm() {


    }

    Context context;

    public String setSpinnerArray(Context myContext, Spinner mySpinner, String message) {
        String response = "", list = "";
        this.context = myContext;
        TCPClient TimeTable = new TCPClient("192.168.0.105", 5000, message);
        TimeTable.execute();
        try {
            list = TimeTable.get().toString();
        } catch (InterruptedException e) {

            e.printStackTrace();
            return "H";
        } catch (ExecutionException e) {
            e.printStackTrace();
            return "H";
        }
        String[] optionsSelected = list.split(" ");
        int j = optionsSelected.length;
        List<String> section = new ArrayList<String>();

        for (int i = 0; i < j; i++) {

            section.add(optionsSelected[i]);

        }

        ArrayAdapter<String> sectnAdapter = new ArrayAdapter<String>(this.context, android.R.layout.simple_spinner_item, section);
        sectnAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(sectnAdapter);

        return "T\n";


    }

    public String setTextView(TextView myText, String message) {
        String response = "", list = "";

        TCPClient TimeTable = new TCPClient("192.168.0.105", 5000, message);
        TimeTable.execute();
        try {
            list = TimeTable.get().toString();
        } catch (InterruptedException e) {

            e.printStackTrace();
            return "H";
        } catch (ExecutionException e) {
            e.printStackTrace();
            return "H";
        }

        myText.setText(list);

        return "T\n";



    }

    public int getResponse(String mesg){

        String response = "", list = "";

        TCPClient TimeTable = new TCPClient("192.168.0.105", 5000, mesg);
        TimeTable.execute();
        try {
            list = TimeTable.get().toString();
        } catch (InterruptedException e) {

            e.printStackTrace();

            return 0;
        } catch (ExecutionException e) {
            e.printStackTrace();
            return 0;
        }

        if (list.equals("T\n"))
        {

            return 1;
        }

        return 0;
    }
    public String getString(String mesg){

        String response = "", list = "";

        TCPClient TimeTable = new TCPClient("192.168.0.105", 5000, mesg);
        TimeTable.execute();
        try {
            list = TimeTable.get().toString();
        } catch (InterruptedException e) {

            e.printStackTrace();
            return "H";
        } catch (ExecutionException e) {
            e.printStackTrace();
            return "h";
        }



        return list;
    }


}
