package com.gatikayantra.gy_controlpanel;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ManualBellActivity extends AppCompatActivity {

     String ipaddServer="";
    String ipAdressClient="";
    serverComm mycom=new serverComm();
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual_bell);
        final Intent intent=getIntent();
        ipAdressClient=intent.getExtras().getString("bellIP");
        ipaddServer=intent.getExtras().getString("ipaddServer");
        Button shortBell=(Button)findViewById(R.id.shortBell);
        Button longBell= (Button)findViewById(R.id.longBell);

        Toast.makeText(getApplicationContext(),ipAdressClient, Toast.LENGTH_SHORT)
                .show();
    }

    public void shortBellCall(View view) {
        int response=mycom.getResponse(ipAdressClient,"SB");
        if (response==0){
            Toast.makeText(getApplicationContext(),"Could not ring the bell", Toast.LENGTH_SHORT)
                    .show();
        }
        else  Toast.makeText(getApplicationContext(),"Short bell is for 4 seconds, Please wait unitl bell is complete", Toast.LENGTH_SHORT)
                .show();

    }

    public void LongBellCall(View view) {
        int response=mycom.getResponse(ipAdressClient,"LB");
        if (response==0){
            Toast.makeText(getApplicationContext(),"Could not ring the bell", Toast.LENGTH_SHORT)
                    .show();
        }
        else  Toast.makeText(getApplicationContext(),"Long bell is for 8 seconds, Please wait unitl bell is complete", Toast.LENGTH_SHORT)
                .show();
    }
}
