import sqlite3
import pyexcel
import dbsetup

def prepare_timetable():#tested ok
    try:
        dbase=sqlite3.connect('gatikayantra.db');
        db=dbase.cursor()
        rooms={4:'A',5:'B',6:'C',7:'D'}
        sheet=4
        while sheet<8:
            pyexcel.initialise('/media/pi/SHASHI/gatikayantra.xls',sheet)
            idnum=1
            rowmax=pyexcel.getRowSize()
            row=1
            while row<rowmax:
                typ=1
                while typ<4:
                    data=pyexcel.getRow(row)
                    i=0
                    rowdata=data[1:]
                    for a in rowdata:
                        if a=='' or a==None:
                            rowdata[i]='free'
                        i+=1
                    #print data
                    data1=[idnum,typ]+rowdata+['free']
                    data1=tuple(data1)
                    #print data1
                    statement='insert into '+rooms[sheet]+' values(?,?,?,?,?,?,?,?,?)'
                    #print statement
                    db.execute(statement,data1)
                    dbase.commit()
                    typ+=1
                    row+=1
                
                idnum+=1
            sheet+=1
        db.close()
        print 'Done TB'
        if prepare_sec_table():
            return True
        else:
            return False            

    except:
        return False


        
def prepare_timelist():#tested ok
    try:
        print dbsetup.create_db()
        dbase=sqlite3.connect('gatikayantra.db');
        db=dbase.cursor()
        pyexcel.initialise('/media/pi/SHASHI/gatikayantra.xls',0)
        rowmax=pyexcel.getRowSize()
        print rowmax
        row=1
        while row<rowmax:
            data=pyexcel.getRow(row)
            i=0
            for a in data:
                data[i]=a.strip('t')
                i+=1
            data1=[row]+data
            data1=tuple(data1)
            statement='insert into normaltime values(?,?,?)'
            #print data1
            db.execute(statement,data1)
            dbase.commit()
            row+=1
        print 'Done TL'
        db.close()
        return True
        
    except:
        return False


def prepare_sec_table():
    try:
        dbase=sqlite3.connect('gatikayantra.db');
        db=dbase.cursor()
        rooms={4:'A',5:'B',6:'C',7:'D'}
        if create_empty_table():
            sheet=4
            while sheet<8:#accessing room timetables
                pyexcel.initialise('/media/pi/SHASHI/gatikayantra.xls',sheet)
                idnum=1
                rowmax=pyexcel.getRowSize()
                row=1
                while row<rowmax:#fetches every row of room timetable
                    i=0
                    period=[]
                    while i<3:#fetches one period of entire week
                        data=pyexcel.getRow(row)
                        rowdata=data[1:]
                        k=0
                        for a in rowdata:#detecting and replacing empty cell with 'free'
                            if a==''or a==None:
                                rowdata[k]='free'
                            k+=1
                        
                        period=period+[rowdata]
                        i+=1
                        row+=1
                    sections=period[0]#sections of entire week for that period
                    subjects=period[1]#subjects of entire week for that period
                    lecturers=period[2]#lectrers of entire week for that period
                    #print period
                    j=0
                    day=['monday','tuesday','wednesday','thursday','friday','saturday']
                    for a in sections:#getting section name
                        if a!='free' and a!='FREE':
                            typ=1
                            statement='update _'+a+' set '+day[j]+'=? where id=? and typ=?'
                            data=(rooms[sheet],idnum,typ)#room for section 'a' coressponding to period 'idnum'
                            db.execute(statement,data)
                            dbase.commit()
                            typ=2
                            data=(subjects[j],idnum,typ)#subject for section 'a' coressponding to period 'idnum'
                            #print data
                            db.execute(statement,data)
                            dbase.commit()
                            typ=3
                            data=(lecturers[j],idnum,typ)#lecturer for section 'a' coressponding to period 'idnum'
                            #print data
                            db.execute(statement,data)
                            dbase.commit()
                        j+=1
                    
                    idnum+=1
                    print 'wait'
                    
                sheet+=1
            db.close()
            return True
        else:
            return False
        
    except:
        return False




def create_empty_table():
    try:
        dbase=sqlite3.connect('gatikayantra.db');
        db=dbase.cursor()
        db.execute('select * from sections')
        sections=db.fetchall()
        if sections:
            print 'wait'
            sheet=1
            for a  in sections:#creates table for each section
                a=''.join(a)
                statement='''create table _'''+a+'''(id int,typ int,monday text,tuesday text,wednesday text,thursday text,friday text,saturday text,sunday text);'''
                #print 'wait'
                db.execute(statement)

            db.execute('select id from normaltime')
            rowmax=len(db.fetchall())
            print rowmax

            for a in sections:#generates empty section timetables for each section in 'sections_list'
                print 'wait'                
                a=''.join(a)                    
                idnum=1
                row=1
                while row<=rowmax:#generates a single empty section timetable of 'rowmax' periods
                    typ=1
                    while typ<4:
                        i=0
                        rowdata=[]
                        while i<7:
                            rowdata=rowdata+['free']#generating 'free'  each day
                            i+=1
                        
                        data1=[idnum,typ]+rowdata
                        data1=tuple(data1)
                        #print data1
                        statement='insert into _'+a+' values(?,?,?,?,?,?,?,?,?)'
                        #print 'wait'
                        db.execute(statement,data1)
                        dbase.commit()
                        typ+=1

                    idnum+=1
                    row+=1
            db.close()
            return True
        
        else:
            return False     

    except:
        return False


def read_sec_list():
    try:
        dbase=sqlite3.connect('gatikayantra.db');
        db=dbase.cursor()
        sheet=1
        pyexcel.initialise('/media/pi/SHASHI/gatikayantra.xls',sheet)

        sec=pyexcel.getCol(0)
        for a in sec:
            if a!='sections' and a!='Sections' and a!='SECTIONS':
                db.execute('insert into sections values(?)',(a,))
                dbase.commit()
        print sec
        db.close()
        return sec[1:]

    except:
        return False

def read_ipaddrs():
    
        sheet=0
        path='/media/pi/SHASHI/gatikayantra_deviceip.xls'
        pyexcel.initialise(path,sheet)
        
        dbase=sqlite3.connect('gatikayantra.db')
        db=dbase.cursor()
        db.executescript('drop table if exists device_ips')
        dbase.commit()
        db.execute('''create table device_ips (id int primary key,device text,ipaddrs text)''')
        dbase.commit()
    
    
    
        rowmax=pyexcel.getRowSize()
        row=1
        while row<rowmax:
            data=pyexcel.getRow(row)
            data[0]=data[0].upper()
            #data1=(None)+tuple(data)
            print data
            db.execute('insert into device_ips values(?,?,?)',(None,data[0],data[1]))
            dbase.commit()
            row+=1
        db.close()
        return True
        '''except:
        db.execute('insert into device_ips values(?,?,?)',(1,'SERVER','192.168.0.105'))
        dbase.commit()
        return False'''
        
        
        


