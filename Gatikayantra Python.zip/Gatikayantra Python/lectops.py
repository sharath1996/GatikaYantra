import gydb
import time
from bellops import get_session_num
import messenger

def tostring(lst,typ):
    data=''
    for a in lst:
        data=data+''.join(a)+typ
    return data[0:len(data)-1]

def get_lectlist():#for lectname
    statement='select name from staffs'
    lecturers=gydb.opendball(statement)
    lecturers=tostring(lecturers,' ')
    return lecturers

def edit_lect_list(x):#for editlect
    x=x.split()
    statement='update staffs set name=? where id=?'
    new_name=x[2]
    index=int(x[1])+1
    data=[new_name,index]
    old_lectlist=get_lectlist().split()
    #old_lectlist=old_lectlist
    
    old_name=old_lectlist[index-1]
    if old_name.lower()!=new_name.lower():
        old_name='_'+old_name
        new_name='_'+new_name
        print old_name,new_name
        gydb.change_table_name(old_name,new_name)
        flag=gydb.updatedb(statement,data)
    else:
        flag='F\n'
    print flag
    return flag
       
def add_lect(x):#for addlect
    x=x.split()
    statement='insert into staffs values(?,?,?)'
    data=[None,x[1],'admin']
    resp=gydb.addtodb(statement,data)
    if resp!=None:
        return True
    else:
        return False

def lect_login(x):#for aut and ver
    #try:
        y=x.split()
        query=y[0]
        index=int(y[1])+1
        lpsw=y[2]
        namepsw=gydb.opendbone('select name,password from staffs where id=?',index)
        psw=''.join(namepsw[1])
        name=''.join(namepsw[0])
        print namepsw
        if psw==lpsw:
            if query=='aut':
                tt=login_session(name)
                msg=messenger.read_msg(name)
                return tt+'-'+msg+'\n'
            elif query=='ver':
                return 'T\n'
        else:
            return 'F\n'
'''except:
        print "exception in faculty login. Check if passowrd left blank"
        return 'F\n'''

def lect_changepsw(x):#for Fchange
    try:
        y=x.split()
        index=int(y[1])+1
        newpsw=y[2]
        data=[newpsw,index]
        if gydb.updatedb('update staffs set password=? where id=?',data):
            return 'T\n'
        else:
            return 'F\n'
    except:
        return 'F\n'

def get_lect_timetable(x):#for lect_timetable
    y=x.split()
    name=y[1]
    index=int(y[2])+1
    day=y[3].lower()
    statement='select '+day+' from _'+name+' where id=?'
    print statement
    period=gydb.opentimetable(statement,index)
    period=tostring(period,' ')
    print period
    return period

def login_session(name):
    #try:
        idnum=get_session_num()
        if idnum:        
            day=time.strftime("%A",time.localtime()).lower()
            statement='select '+day+' from _'+name+' where id=?'
            data=gydb.opentimetable(statement,str(idnum))
            data=tostring(data,'-')
            #print data
        else:
            data='F-F-F'
        return data
'''except:
        print 'error in lectops.login_session'
        return 'F-F-F'''
