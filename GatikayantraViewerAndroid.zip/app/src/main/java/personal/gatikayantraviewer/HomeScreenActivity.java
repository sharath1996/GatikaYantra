package personal.gatikayantraviewer;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.ExecutionException;

public class HomeScreenActivity extends AppCompatActivity {

    TextView room,section,faculty,subject,info;
    Spinner roomSelector;
    Calendar rightNow = Calendar.getInstance();
    serverComm mycomm=new serverComm();
    String timeList1,timePhone,response,reply,j;
    String[] timeList;
    SimpleDateFormat simpleDateFormat;
ServerSocket socket;
    Socket s;
    public PrintWriter out;
    String finalMessage;
    public int len,sec,min,hour;
    boolean matchFound=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);



        room = (TextView) findViewById(R.id.roomText);
        section = (TextView) findViewById(R.id.sectionText);
        faculty = (TextView) findViewById(R.id.facultyText);
        subject = (TextView) findViewById(R.id.subjectText);
        info = (TextView) findViewById(R.id.infoText);


        Log.w("server", "initialised");

        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    //Create a server socket object and bind it to a port
                    ServerSocket socServer = new ServerSocket(6000);
                    //Create server side client socket reference
                    Socket socClient = null;
                    //Infinite loop will listen for client requests to connect
                    while (true) {
                        //Accept the client connection and hand over communication to server side client socket
                        socClient = socServer.accept();
                        //For each client new instance of AsyncTask will be created
                        ServerAsyncTask serverAsyncTask = new ServerAsyncTask();
                        //Start the AsyncTask execution
                        //Accepted client socket object will pass as the parameter
                        serverAsyncTask.execute(new Socket[] {socClient});
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();

    /**
     * Get ip address of the device
     */



    /**
     * AsyncTask which handles the commiunication with clients
     */






    }
    class ServerAsyncTask extends AsyncTask<Socket, Void, String> {
        //Background task which serve for the client
        @Override
        protected String doInBackground(Socket... params) {
            String result = null;
            //Get the accepted socket object
            Socket mySocket = params[0];
            try {
                //Get the data input stream comming from the client
                BufferedReader  in = new BufferedReader(new InputStreamReader(mySocket.getInputStream()));
                //Get the output stream to the client
                finalMessage =in.readLine()+System.getProperty("line.separator");
                response=finalMessage;
                PrintWriter out = new PrintWriter(
                        mySocket.getOutputStream(), true);
                //Write data to the data output stream
                out.println("T\n");
                //Buffer the data input stream

                //while(true)

                //Read the contents of the data buffer
                result = finalMessage;
                //Close the client connection
                Log.w("server","SEDDD");
                mySocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            Log.w("server","PostExecte");
            String[] res=s.split("-"); //After finishing the execution of background task data will be write the text view
          if(res[0].equals("message")){
              info.setText(res[1]);
           }
            else{

              room.setText(res[0]);

            section.setText(res[1]);
            faculty.setText(res[3]);
            subject.setText(res[2]);}


        }
    }

        }










