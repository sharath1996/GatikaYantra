package com.gatikayantra.gy_controlpanel;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class ControlScreenActivity extends AppCompatActivity {

    String ipaddServer="";

   String ipaddBell="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control_screen);
        final Intent intent=getIntent();
        ipaddServer=intent.getExtras().getString("mainServerIP");
        ipaddBell=intent.getExtras().getString("bellIP");
    }

    public void calenderFunctions(View view) {

        Intent intent1 = new Intent(view.getContext(), CalenderActivity.class);
        intent1.putExtra("mainServerIP", ipaddServer);
        intent1.putExtra("bellIP", ipaddBell);

        startActivity(intent1);
    }

    public void manualBellFunction(View view) {

        Intent intent1 = new Intent(view.getContext(), ManualBellActivity.class);
        intent1.putExtra("mainServerIP", ipaddServer);
        intent1.putExtra("bellIP", ipaddBell);

        startActivity(intent1);
    }

    public void announcementFunction(View view) {

        Intent intent1 = new Intent(view.getContext(), GeneralAnnouncementActivity.class);
        intent1.putExtra("mainServerIP", ipaddServer);
        intent1.putExtra("bellIP", ipaddBell);

        startActivity(intent1);
    }

    public void updateDatabaseFunction(View view) {
        serverComm mycom=new serverComm();
        String j = mycom.getText(ipaddServer, "read_db");
        if (j.equals("T\n")) {
            Toast.makeText(getApplicationContext(),"Database update started.......", Toast.LENGTH_SHORT)
                    .show();

        }
        else {
            Toast.makeText(getApplicationContext(),"Cannot update database", Toast.LENGTH_SHORT)
                    .show();

        }
    }




    public void PasswordChangeFunction(View view) {
        Intent intent1 = new Intent(view.getContext(), PasswordChangeActivity.class);
        intent1.putExtra("mainServerIP", ipaddServer);
        intent1.putExtra("bellIP", ipaddBell);

        startActivity(intent1);
    }
}
