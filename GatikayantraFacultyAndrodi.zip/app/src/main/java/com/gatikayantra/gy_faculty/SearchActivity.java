package com.gatikayantra.gy_faculty;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class SearchActivity extends AppCompatActivity {


    Button roomDetButton,sectionDetButton;
    Spinner  roomList,sectionList,TimeList,Daylist;
    TextView fac_name,section, subject,faculty;
    serverComm myserver = new serverComm();
    String IPadd2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);


        roomDetButton=(Button)findViewById(R.id.button_room_det);
        sectionDetButton=(Button)findViewById(R.id.Button_secDet);
        roomList =(Spinner)findViewById(R.id.Room_TT_spinner);
        sectionList=(Spinner)findViewById(R.id.Class_TT_spinner);
        TimeList=(Spinner)findViewById(R.id.Time_TT_spinner);
        Daylist=(Spinner)findViewById(R.id.daySpinner);
        fac_name=(TextView)findViewById(R.id.fac_name_TT);
        section=(TextView)findViewById(R.id.sectionDet);
        subject=(TextView)findViewById(R.id.subjectDet);
        faculty=(TextView)findViewById(R.id.FacultyDet);
        Intent intent=getIntent();
        IPadd2=intent.getExtras().getString("IPAdd");
       

        innitialise();




        sectionDetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                 String resp= myserver.getText(IPadd2,"queryS "+String.valueOf(sectionList.getSelectedItem())+" "+String.valueOf(TimeList.getSelectedItemPosition())+" "+String.valueOf(Daylist.getSelectedItem()));
                String[] respArray=resp.split("-");
                section.setText(respArray[0]);
                subject.setText(respArray[1]);
                faculty.setText(respArray[2]);
            //    innitialise();

            }
        });
        roomDetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String resp=myserver.getText(IPadd2,"queryR "+String.valueOf(roomList.getSelectedItem())+" "+String.valueOf(TimeList.getSelectedItemPosition())+" "+String.valueOf(Daylist.getSelectedItem()));
                String[] respArray=resp.split("-");
                section.setText(respArray[0]);
                subject.setText(respArray[1]);
                faculty.setText(respArray[2]);
               // innitialise();
            }
        });



    }
    void innitialise(){

        myserver.setSpinnerArray(IPadd2,this,Daylist,"day");
        myserver.setSpinnerArray(IPadd2,this,TimeList,"stl normal");
        myserver.setSpinnerArray(IPadd2,this,roomList,"rml");
        myserver.setSpinnerArray(IPadd2,this,sectionList,"sec");
    }
}
