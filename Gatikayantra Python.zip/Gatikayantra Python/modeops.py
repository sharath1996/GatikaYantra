import gydb
import sqlite3

def check_mode(date):
    
    statement='select mode from specialdates where date=?'
    mode=gydb.opendbone(statement,date)
    tablesname={'normal':"normaltime",'holiday':"holiday",'exam':"examtime",'internals':"internalstime"}
    if mode==None:
        table='normaltime'
    else:
        mode=''.join(mode)
        table=tablesname[mode.lower()]

    return table 


def set_edit_mode(date,mode):
    resp=check_mode(date)
    if mode!='normal':
        if resp=='normaltime':
            statement='insert into specialdates values(?,?)'
            data=(date,mode)
            resp1=gydb.appendtodb(statement,data)
            return resp1
        else:
            statement='update mode from specialdates where date=?'
            data=(mode,date)
            resp1=gydb.updatedb(statement,data)
            return resp1

    else:
        statement='delete from specialdates where date=?'
        resp=gydb.deletedb(statement,(date))
        return resp
 
